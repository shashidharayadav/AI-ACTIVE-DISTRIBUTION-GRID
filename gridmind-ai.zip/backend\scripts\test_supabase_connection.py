"""
GRIDMIND AI - Secure Supabase Connection Verifier
Tests connectivity to the remote Supabase PostgreSQL instance without printing or logging secret keys.
"""
import sys
import os

# Add backend directory to sys.path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.core.config import settings
from app.database.connection import test_supabase_connection, get_supabase_key

def main():
    print("=" * 60)
    print("GRIDMIND AI - Supabase Connection Verifier")
    print("=" * 60)

    url_configured = bool(settings.SUPABASE_URL and settings.SUPABASE_URL.strip())
    key = get_supabase_key()
    key_configured = bool(key and key.strip())

    # Safe display (never expose key)
    if url_configured:
        domain = settings.SUPABASE_URL.split("//")[-1].split("/")[0]
        print(f"[*] SUPABASE_URL configured: https://{domain}")
    else:
        print("[!] SUPABASE_URL: NOT CONFIGURED or EMPTY")

    if key_configured:
        print(f"[*] SUPABASE_SECRET_KEY / KEY configured: [PRESENT - length: {len(key.strip())} chars] (MASKED)")
    else:
        print("[!] SUPABASE_SECRET_KEY / KEY: NOT CONFIGURED or EMPTY")

    if not url_configured or not key_configured:
        print("\n[STATUS] Credentials incomplete. Please check backend/.env file.")
        sys.exit(1)

    print("\nAttempting connection to Supabase...")
    success, message = test_supabase_connection()
    if success:
        print(f"[SUCCESS] {message}")
        sys.exit(0)
    else:
        print(f"[FAILED] {message}")
        sys.exit(2)

if __name__ == "__main__":
    main()
