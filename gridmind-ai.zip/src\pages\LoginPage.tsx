import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Zap,
  Lock,
  Mail,
  Eye,
  EyeOff,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Globe
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Forgot password modal
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email) {
      setError('Please enter your email address.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      login(email);
      setIsLoading(false);
      navigate('/dashboard');
    }, 600);
  };

  const handleQuickDemo = (role: 'Grid Dispatcher' | 'Substation Engineer') => {
    setEmail(role === 'Grid Dispatcher' ? 'dispatcher@gridmind.ai' : 'engineer@gridmind.ai');
    setPassword('DemoPass2026!');
    setIsLoading(true);
    setTimeout(() => {
      login(role === 'Grid Dispatcher' ? 'dispatcher@gridmind.ai' : 'engineer@gridmind.ai', role);
      setIsLoading(false);
      navigate('/dashboard');
    }, 400);
  };

  return (
    <div className="min-h-screen bg-[#101C2C] text-[#F8FAFC] flex flex-col justify-center items-center px-4 py-8 relative overflow-hidden">
      {/* Background Grid Pattern & Glowing Orbs */}
      <div className="absolute inset-0 grid-pattern-bg opacity-30 pointer-events-none" />
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-[#20A99E]/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-[#9585F5]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Top Navigation Bar: Direct link to Public Landing Page */}
      <div className="absolute top-6 left-6 right-6 flex items-center justify-between z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#20A99E] to-[#9585F5] p-0.5 flex items-center justify-center">
            <div className="w-full h-full bg-[#152538] rounded-md flex items-center justify-center">
              <Zap className="w-4 h-4 text-[#20A99E]" />
            </div>
          </div>
          <span className="font-bold text-sm tracking-wider text-[#F8FAFC]">
            GRID<span className="text-[#20A99E]">MIND</span> AI
          </span>
        </div>

        <Link
          to="/landing"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#152538] hover:bg-[#263B50] border border-[#34495E] text-xs font-medium text-[#A9B8C8] hover:text-[#F8FAFC] transition-colors"
        >
          <Globe className="w-3.5 h-3.5 text-[#9585F5]" />
          <span>Public Presentation / Landing Page</span>
        </Link>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md z-10">
        <div className="rounded-2xl bg-[#1D3045] border border-[#34495E] p-8 shadow-2xl relative">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#152538] border border-[#34495E] mb-3 relative group">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#20A99E]/20 to-[#9585F5]/20 blur-sm" />
              <Zap className="w-7 h-7 text-[#20A99E] relative z-10" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-[#F8FAFC]">
              Grid Operations Console
            </h2>
            <p className="text-xs text-[#A9B8C8] mt-1.5">
              Active Distribution Grid Monitoring & Random Forest Demand Prediction
            </p>
          </div>

          {/* Quick Demo Access Bar for Hackathon Evaluators */}
          <div className="mb-6 p-3 rounded-xl bg-[#152538] border border-[#20A99E]/30 text-xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-[#20A99E] font-semibold text-[11px]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>HACKATHON QUICK DEMO LOGIN</span>
              </div>
              <span className="text-[10px] text-[#A9B8C8]">1-Click Enter</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('Grid Dispatcher')}
                className="py-1.5 px-2 rounded-lg bg-[#263B50] hover:bg-[#20A99E]/20 border border-[#34495E] text-[11px] font-medium text-[#F8FAFC] transition-colors text-center"
              >
                Lead Dispatcher
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('Substation Engineer')}
                className="py-1.5 px-2 rounded-lg bg-[#263B50] hover:bg-[#9585F5]/20 border border-[#34495E] text-[11px] font-medium text-[#F8FAFC] transition-colors text-center"
              >
                Substation Engineer
              </button>
            </div>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-[#F16F75]/15 border border-[#F16F75]/30 text-xs text-[#F16F75] flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F16F75]" />
              <span>{error}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1.5">
                Operator Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="operator@gridmind.ai"
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1.5">
                Security Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#A9B8C8] hover:text-[#F8FAFC]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none text-[#A9B8C8] hover:text-[#F8FAFC]">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded bg-[#152538] border-[#34495E] text-[#20A99E] focus:ring-0 focus:ring-offset-0"
                />
                <span>Remember console</span>
              </label>
              <button
                type="button"
                onClick={() => setForgotModalOpen(true)}
                className="text-[#20A99E] hover:underline"
              >
                Forgot password?
              </button>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              variant="primary"
              size="lg"
              loading={isLoading}
              icon={ArrowRight}
              iconPosition="right"
              className="w-full mt-2"
            >
              Sign In to Operations Console
            </Button>
          </form>

          {/* Footer Link to Register */}
          <div className="mt-6 pt-5 border-t border-[#34495E] text-center text-xs text-[#A9B8C8]">
            <span>Need authorized operator access? </span>
            <Link to="/register" className="text-[#20A99E] font-medium hover:underline">
              Register Credentials
            </Link>
          </div>
        </div>

        {/* Security / Hackathon Disclaimer */}
        <div className="mt-4 flex items-center justify-center gap-2 text-[11px] text-[#A9B8C8]/70">
          <ShieldCheck className="w-3.5 h-3.5 text-[#35C99A]" />
          <span>GRIDMIND AI v2.4 • Active Distribution Grid Operations Interface</span>
        </div>
      </div>

      {/* Forgot Password Modal (Frontend Simulation) */}
      <Modal
        isOpen={forgotModalOpen}
        onClose={() => {
          setForgotModalOpen(false);
          setForgotSent(false);
        }}
        title="Reset Operator Password"
        subtitle="Frontend demonstration for password recovery"
        maxWidth="md"
      >
        {forgotSent ? (
          <div className="text-center py-4 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#35C99A]/20 border border-[#35C99A]/40 flex items-center justify-center mx-auto text-[#35C99A]">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-base font-semibold text-[#F8FAFC]">Password Reset Token Dispatched</h4>
            <p className="text-xs text-[#A9B8C8]">
              A temporary authentication reset token has been simulated for{' '}
              <span className="text-[#20A99E] font-medium">{forgotEmail || 'your email'}</span>.
            </p>
            <Button
              variant="secondary"
              size="md"
              onClick={() => {
                setForgotModalOpen(false);
                setForgotSent(false);
              }}
              className="mt-4 w-full"
            >
              Back to Login
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-xs text-[#A9B8C8]">
              Enter your registered utility dispatcher or engineering email address to receive secure OTP
              reset instructions.
            </p>
            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1">Operator Email</label>
              <input
                type="email"
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="operator@gridmind.ai"
                className="w-full px-3 py-2 rounded-lg bg-[#152538] border border-[#34495E] text-sm text-[#F8FAFC] focus:border-[#20A99E] focus:outline-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setForgotModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => setForgotSent(true)}
              >
                Send Reset Link
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
