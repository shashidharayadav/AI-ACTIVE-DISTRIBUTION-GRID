"""
GRIDMIND AI - Electricity Consumption Analytics Routes
"""
from fastapi import APIRouter
from typing import List, Dict, Any
from app.database.repositories.grid_repository import grid_repo
from app.schemas.grid_schemas import ConsumptionCurrentResponse, LocalityConsumptionItem, HourlyConsumptionItem

router = APIRouter(prefix="/consumption", tags=["Consumption"])


@router.get("/current", response_model=ConsumptionCurrentResponse)
def get_current_consumption():
    localities = [LocalityConsumptionItem(**loc) for loc in grid_repo.get_localities()]

    hourly_curve = [
        HourlyConsumptionItem(time="00:00", consumption=2420, predicted=2450, baseline=2400, isPeak=False),
        HourlyConsumptionItem(time="02:00", consumption=2150, predicted=2180, baseline=2200, isPeak=False),
        HourlyConsumptionItem(time="04:00", consumption=1980, predicted=2010, baseline=2050, isPeak=False),
        HourlyConsumptionItem(time="06:00", consumption=2650, predicted=2620, baseline=2500, isPeak=False),
        HourlyConsumptionItem(time="08:00", consumption=3840, predicted=3890, baseline=3600, isPeak=False),
        HourlyConsumptionItem(time="10:00", consumption=4320, predicted=4360, baseline=4100, isPeak=True),
        HourlyConsumptionItem(time="12:00", consumption=4720, predicted=4680, baseline=4500, isPeak=True),
        HourlyConsumptionItem(time="14:00", consumption=4520, predicted=4550, baseline=4350, isPeak=False),
        HourlyConsumptionItem(time="16:00", consumption=4820, predicted=4890, baseline=4600, isPeak=False),
        HourlyConsumptionItem(time="18:00", consumption=5280, predicted=5310, baseline=5100, isPeak=True),
        HourlyConsumptionItem(time="20:00", consumption=5320, predicted=5380, baseline=5150, isPeak=True),
        HourlyConsumptionItem(time="22:00", consumption=3950, predicted=3990, baseline=3800, isPeak=False),
    ]

    return {
        "totalCurrentKw": 4820.0,
        "baselineAverageKw": 4600.0,
        "peakStatus": "Normal / Approaching Peak",
        "localities": localities,
        "hourlyCurve": hourly_curve
    }


@router.get("/localities", response_model=List[LocalityConsumptionItem])
def get_locality_breakdown():
    return [LocalityConsumptionItem(**loc) for loc in grid_repo.get_localities()]


@router.get("/feeders")
def get_feeder_consumption():
    feeders = grid_repo.get_feeders()
    return [
        {
            "feeder_id": f["id"],
            "feeder_name": f["name"],
            "locality": f["locality"],
            "demand_kw": f["demandKw"],
            "voltage_kv": f["voltageKv"],
            "current_a": f["currentA"],
            "loading_pct": f["feederLoadingPercentage"]
        }
        for f in feeders
    ]
