"""
GRIDMIND AI - Battery Energy Storage System (BESS) API Routes
"""
from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
from app.services.bess_service import bess_service
from app.schemas.grid_schemas import BessStateSchema, BessDispatchActionRequest

router = APIRouter(prefix="/bess", tags=["Battery Storage (BESS)"])


@router.get("/status", response_model=BessStateSchema)
def get_bess_status():
    return BessStateSchema(**bess_service.get_status())


@router.get("/history")
def get_bess_history() -> List[Dict[str, Any]]:
    return bess_service.get_history()


@router.post("/charge")
def charge_bess(payload: BessDispatchActionRequest):
    try:
        result = bess_service.charge(
            requested_power_kw=abs(payload.power_kw),
            duration_hours=payload.duration_hours,
            operator_name=payload.operator_name,
            event_name=f"Manual Dispatch Charge ({abs(payload.power_kw)} kW)"
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/discharge")
def discharge_bess(payload: BessDispatchActionRequest):
    try:
        result = bess_service.discharge(
            requested_power_kw=abs(payload.power_kw),
            duration_hours=payload.duration_hours,
            operator_name=payload.operator_name,
            event_name=f"Manual Dispatch Discharge ({abs(payload.power_kw)} kW)"
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/setpoint")
def set_bess_dispatch_setpoint(payload: BessDispatchActionRequest):
    try:
        result = bess_service.set_dispatch_setpoint(
            setpoint_kw=payload.power_kw,
            duration_hours=payload.duration_hours,
            operator_name=payload.operator_name
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/reset")
def reset_bess_nominal():
    return bess_service.reset_to_nominal()
