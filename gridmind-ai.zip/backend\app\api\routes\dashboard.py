"""
GRIDMIND AI - Dashboard Overview API Route
"""
from fastapi import APIRouter
from app.database.repositories.grid_repository import grid_repo
from app.services.energy_calculations import calculate_energy_balance
from app.services.alert_service import alert_service
from app.schemas.grid_schemas import DashboardOverviewResponse

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/overview", response_model=DashboardOverviewResponse)
def get_dashboard_overview():
    """
    Returns consolidated active distribution grid overview:
    - Current electricity consumption (4,820 kW)
    - Predicted demand (+30m: 5,140 kW)
    - Active transformers (18/18) & feeders (24/24)
    - Net Available Energy Balance (+837 kW Usable Surplus)
    - Active alerts and recent SCADA activity
    """
    # Centralized Energy Balance: 5,400 kW Supply - (4,820 kW Demand - 350 kW Solar) - 93 kW Losses = +837 kW
    balance = calculate_energy_balance(
        incoming_supply_kw=5400.0,
        consumer_demand_kw=4820.0,
        solar_generation_kw=350.0,
        network_losses_kw=93.0,
        bess_charging_kw=0.0,
        bess_discharging_kw=0.0
    )

    alert_metrics = alert_service.get_alert_metrics()
    active_alerts = alert_service.get_active_alerts()

    summary = {
        "currentConsumptionKw": 4820.0,
        "predictedDemandKw": 5140.0,
        "activeTransformers": 18,
        "totalTransformers": 18,
        "activeFeeders": 24,
        "totalFeeders": 24,
        "gridHealthScore": 98.4,
        "frequencyHz": 50.02,
        "voltageKv": 11.04,
        "powerFactor": 0.98,
        "activeAlertsCount": alert_metrics["active_count"],
        "criticalAlertsCount": alert_metrics["critical_count"],
        "warningAlertsCount": alert_metrics["warning_count"]
    }

    recent_activity = [
        {"id": "ACT-1", "action": "Random Forest Telemetry Sync", "details": "+30m Lookahead predicted 5,140 kW (+6.6% surge)", "timestamp": "3 mins ago", "user": "AI Dispatch Agent"},
        {"id": "ACT-2", "action": "Surplus Feeder Routing", "details": "472 kW net surplus identified on FDR-04; transfer recommended", "timestamp": "14 mins ago", "user": "Surplus Optimizer"},
        {"id": "ACT-3", "action": "BESS Storage Charge Initiated", "details": "Substation Central 10 MWh BESS absorbing 420 kW surplus", "timestamp": "25 mins ago", "user": "BESS Automator"},
        {"id": "ACT-4", "action": "Tap Changer Stepped", "details": "TR-102 tap position moved to Position 5 (10.98 kV nominal)", "timestamp": "42 mins ago", "user": "Substation Engineer"}
    ]

    return {
        "summary": summary,
        "energy_balance": balance,
        "active_alerts": active_alerts[:3],
        "recent_activity": recent_activity,
        "system_status": "ONLINE",
        "model_version": "RF-FORECAST v2.4"
    }
