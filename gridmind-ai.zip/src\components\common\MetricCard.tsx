import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus, Sparkles } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon: LucideIcon;
  trend?: {
    value: number | string;
    direction: 'up' | 'down' | 'neutral';
    label?: string;
  };
  subtitle?: string;
  accent?: 'teal' | 'emerald' | 'violet' | 'amber' | 'red';
  isAi?: boolean;
  aiBadgeText?: string;
  onClick?: () => void;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  unit,
  icon: Icon,
  trend,
  subtitle,
  accent = 'teal',
  isAi = false,
  aiBadgeText = 'RANDOM FOREST REGRESSION AI',
  onClick,
}) => {
  const accentStyles = {
    teal: {
      border: 'hover:border-[#20A99E]/50',
      iconBg: 'bg-[#20A99E]/10 text-[#20A99E]',
      glow: 'group-hover:shadow-[0_0_20px_-5px_rgba(32,169,158,0.25)]',
      trendColor: 'text-[#35C99A]',
    },
    emerald: {
      border: 'hover:border-[#35C99A]/50',
      iconBg: 'bg-[#35C99A]/10 text-[#35C99A]',
      glow: 'group-hover:shadow-[0_0_20px_-5px_rgba(53,201,154,0.25)]',
      trendColor: 'text-[#35C99A]',
    },
    violet: {
      border: 'hover:border-[#9585F5]/60 border-[#9585F5]/40 shadow-[0_0_15px_-4px_rgba(149,133,245,0.2)]',
      iconBg: 'bg-[#9585F5]/15 text-[#9585F5]',
      glow: 'group-hover:shadow-[0_0_20px_-5px_rgba(149,133,245,0.35)]',
      trendColor: 'text-[#9585F5]',
    },
    amber: {
      border: 'hover:border-[#F5B942]/50',
      iconBg: 'bg-[#F5B942]/10 text-[#F5B942]',
      glow: 'group-hover:shadow-[0_0_20px_-5px_rgba(245,185,66,0.25)]',
      trendColor: 'text-[#F5B942]',
    },
    red: {
      border: 'hover:border-[#F16F75]/50',
      iconBg: 'bg-[#F16F75]/10 text-[#F16F75]',
      glow: 'group-hover:shadow-[0_0_20px_-5px_rgba(241,111,117,0.25)]',
      trendColor: 'text-[#F16F75]',
    },
  }[accent];

  return (
    <div
      onClick={onClick}
      className={`group relative rounded-xl bg-[#1D3045] border border-[#34495E] p-4 sm:p-5 transition-all duration-300 flex flex-col justify-between ${accentStyles.border} ${accentStyles.glow} ${
        onClick ? 'cursor-pointer transform hover:-translate-y-0.5' : ''
      }`}
    >
      <div>
        {/* Top Header Row */}
        {isAi ? (
          <div className="flex items-center justify-between gap-2 mb-2.5">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-[#9585F5]/20 border border-[#9585F5]/40 px-2.5 py-0.5 text-[9px] sm:text-[10px] font-bold tracking-wider text-[#9585F5] shrink-0">
              <Sparkles className="w-3 h-3 text-[#9585F5] shrink-0" />
              <span>{aiBadgeText}</span>
            </div>
            <div className={`p-2 rounded-lg border border-[#34495E]/50 shrink-0 ${accentStyles.iconBg}`}>
              <Icon className="w-4 h-4" />
            </div>
          </div>
        ) : (
          <div className="flex items-start justify-between gap-2 mb-2">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#A9B8C8] leading-snug">
              {title}
            </p>
            <div className={`p-2 rounded-lg border border-[#34495E]/50 shrink-0 ${accentStyles.iconBg}`}>
              <Icon className="w-4 h-4" />
            </div>
          </div>
        )}

        {/* Title for AI Card (clearly separated below badge) */}
        {isAi && (
          <p className="text-xs font-semibold text-[#F8FAFC] tracking-wide mb-1 leading-snug">
            {title}
          </p>
        )}

        {/* Numerical Value and Unit */}
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-2xl sm:text-[26px] font-extrabold tracking-tight text-[#F8FAFC]">
            {value}
          </span>
          {unit && (
            <span className="text-xs sm:text-sm font-semibold text-[#A9B8C8]">
              {unit}
            </span>
          )}
        </div>
      </div>

      {/* Footer Trend & Subtitle Row */}
      {(trend || subtitle) && (
        <div className="mt-3.5 pt-2.5 border-t border-[#34495E]/60 flex flex-wrap items-center justify-between gap-1.5 text-xs">
          {trend ? (
            <div className="flex items-center gap-1.5 font-semibold">
              {trend.direction === 'up' && (
                <span className={`inline-flex items-center gap-0.5 ${accentStyles.trendColor}`}>
                  <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
                  {trend.value}
                </span>
              )}
              {trend.direction === 'down' && (
                <span className="inline-flex items-center gap-0.5 text-[#35C99A]">
                  <ArrowDownRight className="w-3.5 h-3.5 shrink-0" />
                  {trend.value}
                </span>
              )}
              {trend.direction === 'neutral' && (
                <span className="inline-flex items-center gap-0.5 text-[#A9B8C8]">
                  <Minus className="w-3.5 h-3.5 shrink-0" />
                  {trend.value}
                </span>
              )}
              {trend.label && (
                <span className="text-[#A9B8C8] font-normal text-[11px]">
                  {trend.label}
                </span>
              )}
            </div>
          ) : (
            <span className="text-[#A9B8C8] text-[11px] leading-tight">
              {subtitle}
            </span>
          )}
          {subtitle && trend && (
            <span className="text-[#A9B8C8] text-[11px] leading-tight text-right">
              {subtitle}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
