import React, { useState } from 'react';
import {
  Activity,
  Zap,
  Gauge,
  Radio,
  RefreshCw,
  Layers,
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { LiveBadge } from '../components/common/LiveBadge';
import { Button } from '../components/common/Button';
import {
  mockGridSummary,
  mockTransformers,
  mockFeeders,
} from '../data/mockData';

export const GridMonitoring: React.FC = () => {
  const [isSimulating, setIsSimulating] = useState(false);
  const [selectedNode, setSelectedNode] = useState<string | null>('SUB-01');

  // Selected node details helper
  const getNodeDetails = () => {
    if (selectedNode === 'SUB-01') {
      return {
        title: 'North Primary Substation (110kV/11kV Infeed)',
        subtitle: 'Primary Grid Bulk Power Supply Point • Dual 40 MVA Transformers',
        stats: 'Bus: 11.04 kV • Frequency: 50.02 Hz • Active Inflow: 4,820 kW',
        status: 'normal',
      };
    }
    const feeder = mockFeeders.find((f) => f.id === selectedNode);
    if (feeder) {
      return {
        title: `${feeder.name} (${feeder.locality})`,
        subtitle: `Substation: ${feeder.substation} • Breaker: ${feeder.breakerState}`,
        stats: `Voltage: ${feeder.voltageKv} kV • Current: ${feeder.currentA} A • Load: ${feeder.demandKw} kW (${feeder.feederLoadingPercentage}%)`,
        status: feeder.status === 'ONLINE' ? 'normal' : 'warning',
      };
    }
    const transformer = mockTransformers.find((t) => t.id === selectedNode);
    if (transformer) {
      return {
        title: `${transformer.name} (${transformer.id})`,
        subtitle: `${transformer.substation} • Tap Position: ${transformer.tapPosition}`,
        stats: `Load: ${transformer.currentLoadKva}/${transformer.capacityKva} kVA (${transformer.loadingPercentage}%) • Oil: ${transformer.oilTempC}°C • Winding: ${transformer.windingTempC}°C`,
        status: transformer.status,
      };
    }
    return {
      title: 'Active Distribution Node',
      subtitle: 'Distribution Ring Main Unit',
      stats: 'Voltage: 11.02 kV • Power Factor: 0.98',
      status: 'normal',
    };
  };

  const activeNodeInfo = getNodeDetails();
  const busVoltages = [
    { name: 'Bus 1 (North 11kV)', voltage: 11.04, status: 'normal', nominal: 11.0, deviation: '+0.36%' },
    { name: 'Bus 2 (Central Commercial)', voltage: 11.02, status: 'normal', nominal: 11.0, deviation: '+0.18%' },
    { name: 'Bus 3 (Industrial 11kV)', voltage: 10.95, status: 'normal', nominal: 11.0, deviation: '-0.45%' },
    { name: 'Bus 4 (Residential North)', voltage: 10.92, status: 'warning', nominal: 11.0, deviation: '-0.72%' },
    { name: 'Bus 5 (Cyber Corridor)', voltage: 11.08, status: 'normal', nominal: 11.0, deviation: '+0.72%' },
    { name: 'Bus 6 (Renewable Intertie)', voltage: 11.12, status: 'normal', nominal: 11.0, deviation: '+1.09%' },
  ];

  // 3-Phase balance readings
  const phaseReadings = [
    { phase: 'Phase A', current: '148.2 A', voltage: '6.37 kV', pf: 0.98, loading: '74%' },
    { phase: 'Phase B', current: '151.0 A', voltage: '6.35 kV', pf: 0.97, loading: '76%' },
    { phase: 'Phase C', current: '146.8 A', voltage: '6.38 kV', pf: 0.98, loading: '73%' },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-[#F8FAFC]">
              Active Distribution Grid Monitoring
            </h2>
            <LiveBadge label="TELEMETRY STREAM" variant="emerald" />
          </div>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Real-time multi-bus voltage stability, phase balance, and distribution topology
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={isSimulating ? 'ai' : 'secondary'}
            size="sm"
            icon={RefreshCw}
            onClick={() => setIsSimulating(!isSimulating)}
          >
            {isSimulating ? 'Simulating Telemetry Flux...' : 'Simulate Grid Flux'}
          </Button>
        </div>
      </div>

      {/* Grid Key Performance Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Distribution Grid Frequency"
          value={isSimulating ? '50.04' : `${mockGridSummary.frequencyHz}`}
          unit="Hz"
          icon={Gauge}
          subtitle="Nominal 50.00 Hz (±0.2 Hz limit)"
          accent="emerald"
        />
        <MetricCard
          title="Active System Voltage"
          value={isSimulating ? '11.01' : `${mockGridSummary.voltageKv}`}
          unit="kV"
          icon={Activity}
          subtitle="Distribution Bus 11kV Class"
          accent="teal"
        />
        <MetricCard
          title="Total Ingested Active Load"
          value={isSimulating ? '4,950' : `${mockGridSummary.currentConsumptionKw}`}
          unit="kW"
          icon={Zap}
          trend={{ value: '+2.7%', direction: 'up', label: 'hourly delta' }}
          accent="teal"
        />
        <MetricCard
          title="Overall Power Factor"
          value={isSimulating ? '0.97' : `${mockGridSummary.powerFactor}`}
          unit="Lagging"
          icon={Radio}
          subtitle="Capacitor Banks Synced"
          accent="emerald"
        />
      </div>

      {/* Interactive Topology Visualizer */}
      <Card
        title="Interactive Distribution Grid Topology"
        subtitle="Click any node (Substation, Feeder, Transformer, Locality) to inspect live telemetry"
        highlight="teal"
      >
        <div className="bg-[#101C2C] rounded-xl p-5 border border-[#34495E] overflow-x-auto">
          <div className="min-w-[800px] flex items-center justify-between gap-6 relative">
            {/* Main Substation Node */}
            <div
              onClick={() => setSelectedNode('SUB-01')}
              className={`cursor-pointer p-4 rounded-xl border transition-all text-center w-52 shrink-0 ${
                selectedNode === 'SUB-01'
                  ? 'bg-[#1D3045] border-[#20A99E] shadow-[0_0_20px_rgba(32,169,158,0.3)]'
                  : 'bg-[#152538] border-[#34495E] hover:border-[#20A99E]/50'
              }`}
            >
              <div className="w-10 h-10 rounded-lg bg-[#20A99E]/20 text-[#20A99E] flex items-center justify-center mx-auto mb-2">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="text-xs font-bold text-[#F8FAFC]">North Primary Substation</h4>
              <p className="text-[10px] text-[#A9B8C8] mt-0.5">110kV / 11kV Grid Infeed</p>
              <div className="mt-2 pt-2 border-t border-[#34495E] flex justify-between text-[10px]">
                <span className="text-[#A9B8C8]">Bus: 11.04 kV</span>
                <span className="text-[#35C99A] font-semibold">NORMAL</span>
              </div>
            </div>

            {/* Connecting bus line */}
            <div className="flex-1 h-0.5 bg-gradient-to-r from-[#20A99E] via-[#35C99A] to-[#9585F5] relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-[9px] font-mono px-2 py-0.5 rounded bg-[#1D3045] border border-[#34495E] text-[#20A99E]">
                11kV DISTRIBUTION RING BUS
              </div>
            </div>

            {/* Feeders Column */}
            <div className="flex flex-col gap-3 w-56 shrink-0">
              {mockFeeders.slice(0, 3).map((fdr) => (
                <div
                  key={fdr.id}
                  onClick={() => setSelectedNode(fdr.id)}
                  className={`cursor-pointer p-2.5 rounded-lg border transition-all text-left ${
                    selectedNode === fdr.id
                      ? 'bg-[#1D3045] border-[#35C99A] shadow-[0_0_15px_rgba(53,201,154,0.3)]'
                      : 'bg-[#152538] border-[#34495E] hover:border-[#35C99A]/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#F8FAFC]">{fdr.id}</span>
                    <StatusBadge status={fdr.status === 'ONLINE' ? 'normal' : 'warning'} size="sm" />
                  </div>
                  <p className="text-[10px] text-[#A9B8C8] truncate mt-0.5">{fdr.locality}</p>
                  <div className="flex justify-between text-[10px] mt-1 text-[#35C99A]">
                    <span>{fdr.demandKw} kW</span>
                    <span>{fdr.feederLoadingPercentage}% Load</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Connecting arrow */}
            <div className="w-8 h-0.5 bg-[#34495E]" />

            {/* Transformer Fleet Column */}
            <div className="flex flex-col gap-3 w-56 shrink-0">
              {mockTransformers.slice(0, 3).map((tr) => (
                <div
                  key={tr.id}
                  onClick={() => setSelectedNode(tr.id)}
                  className={`cursor-pointer p-2.5 rounded-lg border transition-all text-left ${
                    selectedNode === tr.id
                      ? 'bg-[#1D3045] border-[#9585F5] shadow-[0_0_15px_rgba(149,133,245,0.3)]'
                      : 'bg-[#152538] border-[#34495E] hover:border-[#9585F5]/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#F8FAFC]">{tr.id}</span>
                    <StatusBadge status={tr.status} size="sm" />
                  </div>
                  <p className="text-[10px] text-[#A9B8C8] truncate mt-0.5">Cap: {tr.capacityKva} kVA</p>
                  <div className="flex justify-between text-[10px] mt-1">
                    <span className="text-[#A9B8C8]">{tr.oilTempC}°C Oil</span>
                    <span
                      className={`font-semibold ${
                        tr.loadingPercentage >= 80 ? 'text-[#F5B942]' : 'text-[#20A99E]'
                      }`}
                    >
                      {tr.loadingPercentage}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Selected Node Details Box */}
        <div className="mt-4 p-4 rounded-xl bg-[#152538] border border-[#34495E] flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#20A99E]/20 text-[#20A99E] flex items-center justify-center font-bold">
              {selectedNode?.slice(0, 3)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#F8FAFC]">{activeNodeInfo.title}</span>
                <span className="text-xs font-mono text-[#20A99E] font-semibold">{selectedNode}</span>
                <StatusBadge status={activeNodeInfo.status as any} size="sm" />
              </div>
              <p className="text-[11px] text-[#A9B8C8] mt-0.5">
                {activeNodeInfo.subtitle}
              </p>
              <p className="text-[11px] font-mono text-[#35C99A] mt-0.5">
                {activeNodeInfo.stats}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#A9B8C8]">Sampling Rate: 500ms</span>
            <Button variant="secondary" size="sm">
              Detailed Telemetry
            </Button>
          </div>
        </div>
      </Card>

      {/* Primary Substation Bus Voltages & 3-Phase Balance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bus Voltages Table */}
        <Card
          title="Primary Bus Voltage Readings"
          subtitle="Nominal standard 11.00 kV (Allowed tolerance ±2.5%)"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#34495E] text-[#A9B8C8] text-[11px] uppercase">
                  <th className="pb-2 font-medium">Bus Identifier</th>
                  <th className="pb-2 font-medium">Voltage (kV)</th>
                  <th className="pb-2 font-medium">Deviation</th>
                  <th className="pb-2 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#34495E]/60">
                {busVoltages.map((bus) => (
                  <tr key={bus.name} className="hover:bg-[#263B50]/30 transition-colors">
                    <td className="py-2.5 font-medium text-[#F8FAFC]">{bus.name}</td>
                    <td className="py-2.5 font-mono text-[#20A99E] font-semibold">
                      {bus.voltage.toFixed(2)} kV
                    </td>
                    <td className="py-2.5 text-[#A9B8C8]">{bus.deviation}</td>
                    <td className="py-2.5 text-right">
                      <StatusBadge status={bus.status as any} size="sm" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* 3-Phase Current & Loading Balance */}
        <Card
          title="Three-Phase Current & Balance Readings"
          subtitle="Distribution Feeder Phase Angle & Load Distribution"
        >
          <div className="space-y-4">
            {phaseReadings.map((p) => (
              <div key={p.phase} className="p-3 rounded-xl bg-[#152538] border border-[#34495E]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-1.5 sm:gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#20A99E] shrink-0" />
                    <span className="text-xs font-bold text-[#F8FAFC]">{p.phase}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-xs">
                    <span className="text-[#A9B8C8]">
                      V: <strong className="text-[#F8FAFC]">{p.voltage}</strong>
                    </span>
                    <span className="text-[#A9B8C8]">
                      I: <strong className="text-[#20A99E]">{p.current}</strong>
                    </span>
                    <span className="text-[#A9B8C8]">
                      PF: <strong className="text-[#35C99A]">{p.pf}</strong>
                    </span>
                  </div>
                </div>
                <div className="h-2 w-full bg-[#101C2C] rounded-full overflow-hidden">
                  <div className="h-full bg-[#20A99E] rounded-full" style={{ width: p.loading }} />
                </div>
              </div>
            ))}

            <div className="p-3 rounded-lg bg-[#263B50]/50 border border-[#34495E] flex items-center justify-between text-xs text-[#A9B8C8]">
              <span>Phase Unbalance Ratio: <strong className="text-[#35C99A]">1.2%</strong> (&lt; 2% standard)</span>
              <span className="text-[11px] text-[#35C99A] font-semibold">BALANCED PHASE STATE</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};
