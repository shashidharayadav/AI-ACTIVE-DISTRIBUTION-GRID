"""
GRIDMIND AI - Comprehensive Automated Test Suite
Implements all 10 mandatory electrical, ML, BESS, alert lifecycle, and simulator tests
specified in Section 23 of the project requirements.
"""
import pytest
from app.services.energy_calculations import (
    calculate_interval_energy,
    calculate_energy_balance,
    calculate_feeder_loading,
    calculate_transformer_loading,
    calculate_bess_charge,
    calculate_bess_discharge,
    calculate_transfer_delivered_and_deficit,
    calculate_voltage_status,
    calculate_phase_imbalance
)
from app.services.alert_service import alert_service
from app.services.simulator_service import simulator_service
from app.services.surplus_service import surplus_service
from app.ml.demand_model import demand_predictor


# =============================================================================
# TEST 1: Energy Balance Calculation (Surplus)
# Supply = 5,400 kW, Demand = 4,820 kW, Solar = 350 kW, Losses = 93 kW
# Expected Net Grid Demand = 4,470 kW
# Expected Net Available Balance = +837 kW
# =============================================================================
def test_energy_balance_surplus():
    res = calculate_energy_balance(
        incoming_supply_kw=5400.0,
        consumer_demand_kw=4820.0,
        solar_generation_kw=350.0,
        network_losses_kw=93.0
    )
    assert res["net_grid_demand_kw"] == 4470.0
    assert res["net_available_balance_kw"] == 837.0
    assert res["status"] == "SURPLUS"
    assert res["is_surplus"] is True


# =============================================================================
# TEST 2: Deficit Identification
# Supply = 900 kW, Demand = 1,050 kW, Solar = 0 kW, Losses = 10 kW
# Expected Net Balance = -160 kW (Deficit)
# =============================================================================
def test_energy_balance_deficit():
    res = calculate_energy_balance(
        incoming_supply_kw=900.0,
        consumer_demand_kw=1050.0,
        solar_generation_kw=0.0,
        network_losses_kw=10.0
    )
    assert res["net_grid_demand_kw"] == 1050.0
    assert res["net_available_balance_kw"] == -160.0
    assert res["status"] == "DEFICIT"
    assert res["is_deficit"] is True


# =============================================================================
# TEST 3: Feeder Loading Calculation
# Actual load = 745 kW, Rated capacity = 1,000 kW
# Expected Loading = 74.5%
# =============================================================================
def test_feeder_loading():
    loading = calculate_feeder_loading(actual_load_kw=745.0, rated_capacity_kw=1000.0)
    assert loading == 74.5


# =============================================================================
# TEST 4: BESS Charging Physics
# Capacity = 10,000 kWh, Initial stored = 6,840 kWh, Charge power = 400 kW,
# Duration = 0.5 hours, Efficiency = 93.8%
# Expected Energy Input = 200 kWh
# Expected Stored Energy Increase = 187.6 kWh
# Expected Final Stored Energy = 7,027.6 kWh
# Expected SOC = 70.276%
# =============================================================================
def test_bess_charging_physics():
    res = calculate_bess_charge(
        capacity_kwh=10000.0,
        current_stored_kwh=6840.0,
        charging_power_kw=400.0,
        duration_hours=0.5,
        charging_efficiency=0.9380
    )
    assert res["energy_input_kwh"] == 200.0
    assert pytest.approx(res["stored_energy_increase_kwh"], 0.01) == 187.6
    assert pytest.approx(res["new_stored_kwh"], 0.01) == 7027.6
    assert pytest.approx(res["new_soc_pct"], 0.001) == 70.276


# =============================================================================
# TEST 5: BESS Discharging Physics
# Capacity = 10,000 kWh, Initial stored = 6,840 kWh, Discharge power = 500 kW,
# Duration = 1.0 hour, Efficiency = 93.8%
# Expected Energy Delivered = 500 kWh
# Expected Stored Energy Decrease = 500 / 0.9380 = 533.049 kWh
# Expected Final Stored Energy = 6,840 - 533.049 = 6,306.951 kWh
# Expected SOC = 63.07%
# =============================================================================
def test_bess_discharging_physics():
    res = calculate_bess_discharge(
        capacity_kwh=10000.0,
        current_stored_kwh=6840.0,
        discharge_power_kw=500.0,
        duration_hours=1.0,
        discharge_efficiency=0.9380
    )
    expected_reduction = 500.0 / 0.9380
    assert res["energy_delivered_kwh"] == 500.0
    assert pytest.approx(res["stored_energy_decrease_kwh"], 0.01) == expected_reduction
    assert pytest.approx(res["new_stored_kwh"], 0.01) == 6840.0 - expected_reduction
    assert pytest.approx(res["new_soc_pct"], 0.01) == (6840.0 - expected_reduction) / 100.0


# =============================================================================
# TEST 6: Partial Deficit Resolution via Inter-Feeder Transfer
# Initial deficit = 60 kW, Sending power = 40 kW, Transfer losses = 2 kW
# Expected Delivered Power = 38 kW
# Expected Remaining Deficit = 22 kW
# Expected Deficit Resolution = PARTIALLY_RESOLVED
# =============================================================================
def test_partial_deficit_resolution():
    res = calculate_transfer_delivered_and_deficit(
        destination_deficit_kw=60.0,
        sending_power_kw=40.0,
        transfer_losses_kw=2.0
    )
    assert res["delivered_power_kw"] == 38.0
    assert res["remaining_deficit_kw"] == 22.0
    assert res["resolution_status"] == "PARTIALLY_RESOLVED"


# =============================================================================
# TEST 7: Alert Lifecycle (ACTIVE -> RESOLVED -> READ)
# Verify that resolving an alert changes status to RESOLVED without marking it as read.
# Verify that marking as read changes is_read = True and decrements unread count.
# =============================================================================
def test_alert_lifecycle():
    initial_unread = alert_service.get_unread_count()
    active_alerts = alert_service.get_active_alerts()
    assert len(active_alerts) > 0
    target_alert = active_alerts[0]
    alert_id = target_alert["id"]

    # 1. Resolve alert
    resolved = alert_service.resolve_alert(alert_id)
    assert resolved["isResolved"] is True
    assert resolved["resolvedAt"] is not None
    # Must NOT be automatically marked as read
    assert resolved["isRead"] is False
    # Unread count should NOT have changed yet
    assert alert_service.get_unread_count() == initial_unread

    # 2. Mark as read
    read = alert_service.mark_as_read(alert_id)
    assert read["isRead"] is True
    assert read["readAt"] is not None
    # Unread count decrements by 1
    assert alert_service.get_unread_count() == initial_unread - 1


# =============================================================================
# TEST 8: Demand Prediction Model Accuracy & Evaluation
# Verify chronological split evaluation metrics: MAE, RMSE, MAPE
# =============================================================================
def test_demand_prediction_model():
    res = demand_predictor.predict_horizon(
        horizon="30m",
        current_demand_kw=4820.0,
        temperature_c=28.5,
        industrial_activity_pct=100.0,
        solar_offset_kw=350.0
    )
    assert res["predicted_demand_kw"] > 0.0
    assert res["horizon"] == "+30M"
    assert "r2_score" in res
    assert "mae_kw" in res
    assert "mape_pct" in res
    assert res["mae_kw"] > 0.0
    assert res["mape_pct"] < 10.0  # High-quality forecast (< 10% MAPE)


# =============================================================================
# TEST 9: What-If Simulator Calculation Engine
# Verify dynamic sensitivity updates across temperature, solar, and BESS
# =============================================================================
def test_what_if_simulator_engine():
    # Nominal run
    nominal = simulator_service.calculate_simulation(
        demand_change_pct=0.0,
        solar_pv_generation_kw=350.0,
        industrial_activity_pct=100.0,
        ambient_temperature_c=28.5,
        grid_supply_kw=5400.0,
        bess_dispatch_kw=-420.0
    )
    assert nominal["baseline_demand_kw"] == 4820.0
    assert nominal["grid_balance_status"] in ["SURPLUS", "BALANCED", "DEFICIT"]

    # Heatwave surge run (+26% demand, 41.5°C temp)
    stressed = simulator_service.calculate_simulation(
        demand_change_pct=26.0,
        solar_pv_generation_kw=600.0,
        industrial_activity_pct=110.0,
        ambient_temperature_c=41.5,
        grid_supply_kw=5400.0,
        bess_dispatch_kw=1500.0
    )
    # Stressed consumer demand must be greater than nominal
    assert stressed["total_consumer_demand_kw"] > nominal["total_consumer_demand_kw"]
    assert len(stressed["active_warnings"]) > 0


# =============================================================================
# TEST 10: Network Topology Constraints Check
# Verify that disconnected routes or unsafe transfers are rejected
# =============================================================================
def test_network_constraints():
    # Connected route FDR-01 -> FDR-03
    assert surplus_service.verify_route_connectivity("FDR-01", "FDR-03") is True

    # Disconnected / invalid node check
    assert surplus_service.verify_route_connectivity("FDR-01", "NON_EXISTENT_FEEDER") is False
    assert surplus_service.verify_route_connectivity("FDR-01", "FDR-01") is False

    rec = surplus_service.generate_transfer_recommendation("FDR-01", "FDR-03")
    assert rec["constraints_passed"] is True
    assert rec["recommendation_status"] == "SAFE_TO_RECOMMEND"
    assert rec["recommendedTransferKw"] <= rec["tieLineCapacityKw"]
