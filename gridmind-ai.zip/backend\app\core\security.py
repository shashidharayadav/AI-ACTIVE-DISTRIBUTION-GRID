"""
GRIDMIND AI - Security & Authentication Utilities
"""
from typing import Optional, Dict, Any
from fastapi import Header, HTTPException, status
import logging

logger = logging.getLogger("gridmind.security")


async def get_current_operator(
    authorization: Optional[str] = Header(None)
) -> Dict[str, Any]:
    """
    Validates operator authorization header.
    In development and demo mode, defaults to Lead Dispatcher operator credentials
    if Bearer token is simulated, and verifies Supabase JWT if configured.
    """
    if not authorization:
        # Development / Demo session default
        return {
            "id": "usr-demo-lead-dispatcher",
            "name": "Operator Demo Session",
            "email": "dispatcher@gridmind.ai",
            "role": "Lead Dispatcher",
            "is_authenticated": True
        }

    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication scheme. Bearer required."
        )

    # In production with Supabase, supabase.auth.get_user(token) can be called
    return {
        "id": "usr-verified-operator",
        "name": "Lead Dispatcher",
        "email": "dispatcher@gridmind.ai",
        "role": "Lead Dispatcher",
        "is_authenticated": True,
        "token": token
    }
