"""
GRIDMIND AI - Surplus & Deficit Management API Routes
"""
from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any, Optional
from app.services.surplus_service import surplus_service
from app.database.repositories.grid_repository import grid_repo
from app.schemas.grid_schemas import TransferRecommendationSchema, TransferApprovalRequest

router = APIRouter(prefix="/surplus", tags=["Surplus Management"])


@router.get("/overview")
def get_surplus_overview() -> Dict[str, Any]:
    """
    Returns distribution grid surplus, deficit, and tie-line transfer overview.
    """
    balances = surplus_service.evaluate_feeder_balances()
    total_surplus = sum(b["balance_kw"] for b in balances if b["is_surplus"])
    total_deficit = sum(abs(b["balance_kw"]) for b in balances if b["is_deficit"])

    return {
        "total_surplus_kw": round(total_surplus, 1),
        "total_deficit_kw": round(total_deficit, 1),
        "net_dispatchable_kw": round(total_surplus - total_deficit, 1),
        "active_recommendations_count": len(grid_repo.get_recommendations()),
        "feeder_balances": balances
    }


@router.get("/feeders")
def list_feeder_balances():
    return surplus_service.evaluate_feeder_balances()


@router.get("/recommendations", response_model=List[TransferRecommendationSchema])
def list_recommendations():
    recs = grid_repo.get_recommendations()
    return [TransferRecommendationSchema(**r) for r in recs]


@router.post("/recommendations", response_model=TransferRecommendationSchema)
def create_transfer_recommendation(
    source_feeder_id: str,
    dest_feeder_id: str,
    requested_power_kw: Optional[float] = None
):
    try:
        rec = surplus_service.generate_transfer_recommendation(
            source_feeder_id=source_feeder_id,
            dest_feeder_id=dest_feeder_id,
            requested_power_kw=requested_power_kw
        )
        if not rec.get("constraints_passed"):
            raise HTTPException(status_code=400, detail=rec.get("reason", "Constraint check failed"))
        # Add to repository
        grid_repo.transfer_recommendations.insert(0, rec)
        return TransferRecommendationSchema(**rec)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/recommendations/{rec_id}/approve", response_model=TransferRecommendationSchema)
def approve_recommendation(rec_id: str, payload: TransferApprovalRequest = TransferApprovalRequest()):
    updated = surplus_service.approve_recommendation(rec_id, payload.operator_name)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Recommendation '{rec_id}' not found")
    return TransferRecommendationSchema(**updated)


@router.post("/recommendations/{rec_id}/reject", response_model=TransferRecommendationSchema)
def reject_recommendation(rec_id: str):
    updated = grid_repo.update_recommendation_status(rec_id, "REJECTED")
    if not updated:
        raise HTTPException(status_code=404, detail=f"Recommendation '{rec_id}' not found")
    return TransferRecommendationSchema(**updated)


@router.post("/recommendations/{rec_id}/simulate", response_model=TransferRecommendationSchema)
def simulate_transfer_execution(rec_id: str):
    """
    Simulates transfer progression from APPROVED to COMPLETED.
    """
    updated = surplus_service.simulate_transfer_lifecycle(rec_id)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Recommendation '{rec_id}' not found")
    return TransferRecommendationSchema(**updated)
