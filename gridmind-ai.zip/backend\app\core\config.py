"""
GRIDMIND AI - Application Configuration
"""
from typing import List, Union
from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
import os


class Settings(BaseSettings):
    PROJECT_NAME: str = "GRIDMIND AI - Active Distribution Grid"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    PORT: int = 8000
    HOST: str = "0.0.0.0"

    # CORS
    CORS_ORIGINS: Union[List[str], str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]

    @field_validator("CORS_ORIGINS", mode="before")
    def assemble_cors_origins(cls, v: Union[str, List[str]]) -> List[str]:
        if isinstance(v, str) and not v.startswith("["):
            return [i.strip() for i in v.split(",") if i.strip()]
        elif isinstance(v, list):
            return v
        return ["http://localhost:5173", "http://127.0.0.1:5173"]

    # Supabase Credentials
    SUPABASE_URL: str = ""
    SUPABASE_SECRET_KEY: str = ""
    SUPABASE_ANON_KEY: str = ""
    SUPABASE_SERVICE_ROLE_KEY: str = ""
    DATABASE_URL: str = ""

    @field_validator("SUPABASE_URL", mode="before")
    def validate_supabase_url(cls, v: Any) -> str:
        if isinstance(v, str) and v.strip():
            return v.strip().rstrip("/")
        from dotenv import dotenv_values
        backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        for p in [os.path.join(backend_dir, "backend", ".env"), os.path.join(backend_dir, ".env"), "backend/.env", ".env"]:
            if os.path.exists(p):
                vals = dotenv_values(p)
                url = vals.get("SUPABASE_URL")
                if url and url.strip():
                    return url.strip().rstrip("/")
        return ""

    @field_validator("SUPABASE_SECRET_KEY", mode="before")
    def validate_supabase_secret_key(cls, v: Any) -> str:
        if isinstance(v, str) and v.strip():
            key = v.strip()
            # If an accidental inline concatenation occurred with another env variable
            if "VITE_API_BASE_URL" in key:
                key = key.split("VITE_API_BASE_URL")[0].strip()
            return key
        from dotenv import dotenv_values
        backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        for p in [os.path.join(backend_dir, "backend", ".env"), os.path.join(backend_dir, ".env"), "backend/.env", ".env"]:
            if os.path.exists(p):
                vals = dotenv_values(p)
                key = vals.get("SUPABASE_SECRET_KEY") or vals.get("SUPABASE_SERVICE_ROLE_KEY") or vals.get("SUPABASE_ANON_KEY")
                if key and key.strip():
                    key = key.strip()
                    if "VITE_API_BASE_URL" in key:
                        key = key.split("VITE_API_BASE_URL")[0].strip()
                    return key
        return ""

    # ML & Simulation
    MODEL_DIR: str = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ml", "saved_models")
    SIMULATION_MODE: bool = True
    LOG_LEVEL: str = "INFO"

    # Grid Physics Constants & Nominal Parameters
    NOMINAL_VOLTAGE_KV: float = 11.0
    VOLTAGE_TOLERANCE_PCT: float = 6.0  # +/- 6% permissible band (10.34 kV to 11.66 kV)
    NOMINAL_FREQUENCY_HZ: float = 50.0
    FREQUENCY_TOLERANCE_HZ: float = 0.5 # 49.5 to 50.5 Hz
    TRANSFORMER_WARNING_THRESHOLD_PCT: float = 80.0
    TRANSFORMER_CRITICAL_THRESHOLD_PCT: float = 90.0
    FEEDER_WARNING_THRESHOLD_PCT: float = 80.0
    FEEDER_CRITICAL_THRESHOLD_PCT: float = 90.0

    model_config = SettingsConfigDict(
        env_file=[
            os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "backend", ".env"),
            os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), ".env"),
            ".env",
            "backend/.env",
        ],
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )


settings = Settings()
