import React, { useState } from 'react';
import {
  ArrowLeftRight,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Clock,
  UserCheck,
  Check,
  X,
  GitPullRequest,
  Sliders,
  RotateCcw,
  Zap,
  Network
} from 'lucide-react';
import { mockSurplusTransfers } from '../data/mockData';
import type { SurplusTransferItem, TransferStatus, DeficitResolution } from '../types';
import { useAuth } from '../context/AuthContext';

interface ConstraintResult {
  title: string;
  category: 'CONNECTIVITY' | 'CAPACITY' | 'VOLTAGE' | 'THERMAL' | 'EQUIPMENT';
  status: 'PASS' | 'WARNING' | 'FAIL';
  metric: string;
  reason: string;
}

export const SurplusManagement: React.FC = () => {
  const { user } = useAuth();
  const [transfers, setTransfers] = useState<SurplusTransferItem[]>(mockSurplusTransfers);
  const [filter, setFilter] = useState<'ALL' | TransferStatus>('ALL');
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  // =========================================================
  // INTERACTIVE GRID TOPOLOGY CONSTRAINT CHECKER STATE
  // =========================================================
  const [sourceFeeder, setSourceFeeder] = useState<'FDR-04' | 'FDR-01' | 'FDR-05' | 'FDR-06'>('FDR-04');
  const [destinationFeeder, setDestinationFeeder] = useState<'FDR-03' | 'FDR-02'>('FDR-03');
  const [transferKwInput, setTransferKwInput] = useState<number>(50);
  const [tieBreakerTB04State, setTieBreakerTB04State] = useState<'CLOSED' | 'OPEN'>('CLOSED');
  const [busCouplerBC02State, setBusCouplerBC02State] = useState<'ONLINE' | 'MAINTENANCE'>('ONLINE');
  const [lastCheckTimestamp, setLastCheckTimestamp] = useState<string>('22:15:30');

  // Simulated graph topology connectivity evaluation
  const evaluateConstraints = (): {
    results: ConstraintResult[];
    overallResult: 'SAFE TO RECOMMEND' | 'REQUIRES OPERATOR REVIEW' | 'TRANSFER NOT FEASIBLE';
    pathSummary: string;
  } => {
    const results: ConstraintResult[] = [];

    // Graph topology nodes & edges:
    // FDR-04 on Substation Bus-1
    // FDR-03 on Substation Bus-2
    // TB-04 connects Bus-1 <-> Bus-2 (Capacity: 400 kW)
    // FDR-01 on Cyber Corridor Bus
    // BC-02 connects Cyber Bus <-> Bus-1 (Capacity: 500 kW)
    // FDR-05 on Traction Spur (connects via switch SW-09 to FDR-03)
    // FDR-06 (Healthcare City) has NO inter-tie connection to industrial feeders (isolated radial line for hospital safety)

    let pathExists = true;
    let pathSummary = '';
    let breakerRequired: 'TB-04' | 'BC-02' | 'SW-09' | 'NONE' = 'TB-04';

    if (sourceFeeder === 'FDR-06') {
      pathExists = false;
      pathSummary = 'No inter-tie switch exists between Isolated Healthcare feeder FDR-06 and destination';
    } else if (sourceFeeder === 'FDR-04' && destinationFeeder === 'FDR-03') {
      pathSummary = 'North Bus-1 -> Inter-Tie Breaker TB-04 -> Industrial Feeder FDR-03';
      breakerRequired = 'TB-04';
    } else if (sourceFeeder === 'FDR-01' && destinationFeeder === 'FDR-02') {
      pathSummary = 'Cyber Corridor Bus -> Bus Coupler BC-02 -> Downtown Feeder FDR-02';
      breakerRequired = 'BC-02';
    } else if (sourceFeeder === 'FDR-01' && destinationFeeder === 'FDR-03') {
      pathSummary = 'Cyber Corridor Bus -> BC-02 -> Bus-1 -> TB-04 -> Industrial FDR-03';
      breakerRequired = 'TB-04';
    } else if (sourceFeeder === 'FDR-05') {
      pathSummary = 'Traction Spur -> Sub-Tie Switch SW-09 -> FDR-03';
      breakerRequired = 'SW-09';
    } else {
      pathSummary = `${sourceFeeder} -> Substation Secondary Bus Coupler -> ${destinationFeeder}`;
    }

    // Check 1: Network Connectivity (Graph Path Search)
    if (!pathExists) {
      results.push({
        title: 'Network Connectivity',
        category: 'CONNECTIVITY',
        status: 'FAIL',
        metric: 'NO PATH',
        reason: 'Selected source and destination lack physical tie-line connectivity in distribution topology.',
      });
    } else {
      results.push({
        title: 'Network Connectivity',
        category: 'CONNECTIVITY',
        status: 'PASS',
        metric: 'PATH VERIFIED',
        reason: `Valid electrical topology path identified: ${pathSummary}`,
      });
    }

    // Check 2: Operational Equipment Status
    let equipmentStatusOk = true;
    let equipmentReason = 'All required breakers and bus couplers are closed and energized.';
    if (breakerRequired === 'TB-04' && tieBreakerTB04State === 'OPEN') {
      equipmentStatusOk = false;
      equipmentReason = 'Inter-Tie Breaker TB-04 is in OPEN/TRIP state. Switching disallowed.';
    } else if ((sourceFeeder === 'FDR-01' || breakerRequired === 'BC-02') && busCouplerBC02State === 'MAINTENANCE') {
      equipmentStatusOk = false;
      equipmentReason = 'Bus Coupler BC-02 is undergoing MAINTENANCE isolation.';
    }

    results.push({
      title: 'Equipment Operational Status',
      category: 'EQUIPMENT',
      status: equipmentStatusOk ? 'PASS' : 'FAIL',
      metric: equipmentStatusOk ? 'READY' : 'FAULT / OPEN',
      reason: equipmentReason,
    });

    // Check 3: Feeder Thermal Ampacity Limit (Max transfer based on conductor size)
    const feederAmpacityMaxKw = sourceFeeder === 'FDR-04' ? 220 : 350;
    if (transferKwInput > feederAmpacityMaxKw) {
      results.push({
        title: 'Feeder Thermal Capacity',
        category: 'THERMAL',
        status: 'FAIL',
        metric: `Load: ${transferKwInput} kW (Max ${feederAmpacityMaxKw} kW)`,
        reason: `Transfer power exceeds ${sourceFeeder} conductor thermal rating. Risk of excessive sag.`,
      });
    } else if (transferKwInput > feederAmpacityMaxKw * 0.8) {
      results.push({
        title: 'Feeder Thermal Capacity',
        category: 'THERMAL',
        status: 'WARNING',
        metric: `Load: ${transferKwInput} kW (~${Math.round((transferKwInput / feederAmpacityMaxKw) * 100)}% rating)`,
        reason: `Transfer approaches 80% continuous ampacity on source feeder conductor.`,
      });
    } else {
      results.push({
        title: 'Feeder Thermal Capacity',
        category: 'THERMAL',
        status: 'PASS',
        metric: `Ampacity: ${Math.round((transferKwInput / feederAmpacityMaxKw) * 100)}% of limit`,
        reason: 'Conductor current density is well within IEEE-738 continuous ampacity guidelines.',
      });
    }

    // Check 4: Transformer Capacity (Substation loading margin)
    if (transferKwInput > 300) {
      results.push({
        title: 'Transformer Capacity Margin',
        category: 'CAPACITY',
        status: 'WARNING',
        metric: 'Loading Delta +18%',
        reason: 'Substation TR-1 loading approaches 82% threshold. Cooling fans must be forced ON.',
      });
    } else {
      results.push({
        title: 'Transformer Capacity Margin',
        category: 'CAPACITY',
        status: 'PASS',
        metric: 'Thermal Headroom >30%',
        reason: 'Sufficient MVA capacity remains on substation distribution transformers.',
      });
    }

    // Check 5: Voltage Regulation Limits (Statutory ±6.0%)
    const voltageSagV = parseFloat((transferKwInput * 0.24).toFixed(1));
    const voltageSagPct = parseFloat(((voltageSagV / 11000) * 100).toFixed(2));
    if (voltageSagPct > 5.5) {
      results.push({
        title: 'Voltage Regulation Limits',
        category: 'VOLTAGE',
        status: 'FAIL',
        metric: `Sag: -${voltageSagV}V (${voltageSagPct}%)`,
        reason: 'Exceeds statutory BESCOM ±6.0% busbar voltage regulation limits.',
      });
    } else if (voltageSagPct > 2.5) {
      results.push({
        title: 'Voltage Regulation Limits',
        category: 'VOLTAGE',
        status: 'WARNING',
        metric: `Sag: -${voltageSagV}V (${voltageSagPct}%)`,
        reason: 'Noticeable voltage dip on receiving 11kV bus. AVR tap changer adjustment required.',
      });
    } else {
      results.push({
        title: 'Voltage Regulation Limits',
        category: 'VOLTAGE',
        status: 'PASS',
        metric: `Sag: -${voltageSagV}V (${voltageSagPct}%)`,
        reason: 'Bus voltage remains well within statutory ±6.0% tolerance band.',
      });
    }

    // Check 6: Inter-Tie Transfer Capacity (Tie line limit 400 kW)
    const tieLineLimitKw = 400;
    if (transferKwInput > tieLineLimitKw) {
      results.push({
        title: 'Inter-Tie Transfer Capacity',
        category: 'CAPACITY',
        status: 'FAIL',
        metric: `${transferKwInput} kW / 400 kW`,
        reason: `Proposed transfer exceeds tie-line continuous rating of ${tieLineLimitKw} kW.`,
      });
    } else if (transferKwInput > tieLineLimitKw * 0.85) {
      results.push({
        title: 'Inter-Tie Transfer Capacity',
        category: 'CAPACITY',
        status: 'WARNING',
        metric: `${transferKwInput} kW / 400 kW (85%+)`,
        reason: 'Tie-line utilization exceeds 85% recommended dispatch limit.',
      });
    } else {
      results.push({
        title: 'Inter-Tie Transfer Capacity',
        category: 'CAPACITY',
        status: 'PASS',
        metric: `${transferKwInput} kW / 400 kW Rating`,
        reason: 'Sufficient thermal headroom available on inter-tie breaker and cable run.',
      });
    }

    // Check 7: Phase Imbalance Threshold (< 3.0%)
    const phaseImbalancePct = parseFloat((1.2 + (transferKwInput / 400) * 1.5).toFixed(1));
    if (phaseImbalancePct > 3.0) {
      results.push({
        title: 'Phase Imbalance Margin',
        category: 'VOLTAGE',
        status: 'WARNING',
        metric: `${phaseImbalancePct}% Negative Seq`,
        reason: 'Elevated phase unbalance. Phase balancing capacitor bank recommended.',
      });
    } else {
      results.push({
        title: 'Phase Imbalance Margin',
        category: 'VOLTAGE',
        status: 'PASS',
        metric: `${phaseImbalancePct}% Negative Seq`,
        reason: 'Phase rotational symmetry within standard 3.0% limit.',
      });
    }

    // Check 8: Inter-Tie Connection Availability
    if (breakerRequired === 'TB-04' && tieBreakerTB04State === 'OPEN') {
      results.push({
        title: 'Inter-Tie Connection Availability',
        category: 'CONNECTIVITY',
        status: 'FAIL',
        metric: 'TIE BREAKER OPEN',
        reason: 'TB-04 is physically open; sync-check relay cannot engage until breaker is armed.',
      });
    } else {
      results.push({
        title: 'Inter-Tie Connection Availability',
        category: 'CONNECTIVITY',
        status: 'PASS',
        metric: 'CLOSED & SYNCED',
        reason: 'Bus tie connection is synchronized and ready for power routing.',
      });
    }

    // Overall Synthesis
    const hasFail = results.some((r) => r.status === 'FAIL');
    const warningCount = results.filter((r) => r.status === 'WARNING').length;

    let overallResult: 'SAFE TO RECOMMEND' | 'REQUIRES OPERATOR REVIEW' | 'TRANSFER NOT FEASIBLE' = 'SAFE TO RECOMMEND';
    if (hasFail) {
      overallResult = 'TRANSFER NOT FEASIBLE';
    } else if (warningCount > 0) {
      overallResult = 'REQUIRES OPERATOR REVIEW';
    }

    return { results, overallResult, pathSummary };
  };

  const constraintEvaluation = evaluateConstraints();

  const handleRunConstraintCheck = () => {
    const now = new Date();
    setLastCheckTimestamp(
      `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`
    );
    setFeedbackMessage(`Constraint check completed for ${sourceFeeder} → ${destinationFeeder} (${transferKwInput} kW). Result: ${constraintEvaluation.overallResult}`);
    setTimeout(() => setFeedbackMessage(null), 4500);
  };

  const handleResetConstraints = () => {
    setSourceFeeder('FDR-04');
    setDestinationFeeder('FDR-03');
    setTransferKwInput(50);
    setTieBreakerTB04State('CLOSED');
    setBusCouplerBC02State('ONLINE');
    setFeedbackMessage('Constraint parameters restored to nominal baseline.');
    setTimeout(() => setFeedbackMessage(null), 3000);
  };

  // =========================================================
  // OPERATOR APPROVAL & DEFICIT RESOLUTION WORKFLOW
  // =========================================================
  const handleApprove = (id: string) => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    setTransfers((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const remaining = Math.max(0, t.shortageDemandKw - t.recommendedTransferKw);
          const resolution: DeficitResolution = remaining === 0 ? 'FULLY_RESOLVED' : 'PARTIALLY_RESOLVED';

          return {
            ...t,
            status: 'COMPLETED', // Never both Active and Completed
            deficitResolution: resolution,
            remainingDeficitKw: remaining,
            approvedBy: `${user?.name || 'Grid Dispatcher'} (${user?.role || 'Lead'})`,
            approvedAt: timeStr,
          };
        }
        return t;
      })
    );

    setFeedbackMessage(`Transfer ${id} APPROVED & EXECUTED. Deficit status updated based on transferred power.`);
    setTimeout(() => setFeedbackMessage(null), 4500);
  };

  const handleReject = (id: string) => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    setTransfers((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          return {
            ...t,
            status: 'REJECTED',
            deficitResolution: 'UNRESOLVED',
            approvedBy: `Rejected by ${user?.name || 'Grid Dispatcher'}`,
            approvedAt: timeStr,
          };
        }
        return t;
      })
    );

    setFeedbackMessage(`Transfer ${id} was REJECTED by operator.`);
    setTimeout(() => setFeedbackMessage(null), 4500);
  };

  const filteredTransfers = transfers.filter((t) => {
    if (filter === 'ALL') return true;
    return t.status === filter;
  });

  const pendingCount = transfers.filter((t) => t.status === 'PENDING_APPROVAL').length;
  const approvedCount = transfers.filter((t) => t.status === 'APPROVED' || t.status === 'COMPLETED').length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/30 text-[#20A99E]">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-[#F8FAFC] tracking-tight">
                SURPLUS ELECTRICITY MANAGEMENT
              </h1>
              <p className="text-xs text-[#A9B8C8]">
                Intelligent Inter-Feeder Balancing, Network Topology Routing & Operator Dispatch
              </p>
            </div>
          </div>
        </div>

        {/* Safety & Demo Badges */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-[#101C2C] border border-[#34495E] flex items-center gap-2 text-xs">
            <ShieldCheck className="w-4 h-4 text-[#35C99A]" />
            <span className="text-[#A9B8C8]">Interlock:</span>
            <span className="font-semibold text-[#35C99A]">CONSTRAINTS ENFORCED</span>
          </div>

          <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30">
            SIMULATED DISPATCH
          </span>
        </div>
      </div>

      {/* Operator Notification Feedback Toast */}
      {feedbackMessage && (
        <div className="p-3.5 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/40 text-xs text-[#F8FAFC] flex items-center justify-between shadow-lg animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#20A99E] shrink-0" />
            <span className="font-medium">{feedbackMessage}</span>
          </div>
          <button
            onClick={() => setFeedbackMessage(null)}
            className="text-[#A9B8C8] hover:text-[#F8FAFC] text-sm font-bold px-1"
          >
            ×
          </button>
        </div>
      )}

      {/* 6-Step Simulated Operator Workflow Guide Card */}
      <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-[#F8FAFC] flex items-center gap-2 uppercase tracking-wider">
            <GitPullRequest className="w-4 h-4 text-[#20A99E]" />
            Active Transfer Decision Pipeline (6 Stages)
          </h2>
          <span className="text-[10px] text-[#A9B8C8] font-mono">BESCOM POWER HACK 2026</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2 text-xs">
          <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E] flex flex-col justify-between">
            <div className="text-[10px] font-bold text-[#20A99E] mb-1">01. SURPLUS DETECT</div>
            <div className="font-semibold text-[#F8FAFC]">Identify Source</div>
            <div className="text-[10px] text-[#A9B8C8] mt-1">Locate feeders with excess power</div>
          </div>

          <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E] flex flex-col justify-between">
            <div className="text-[10px] font-bold text-[#9585F5] mb-1">02. DEFICIT DETECT</div>
            <div className="font-semibold text-[#F8FAFC]">Identify Shortage</div>
            <div className="text-[10px] text-[#A9B8C8] mt-1">Locate overloaded local feeders</div>
          </div>

          <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E] flex flex-col justify-between">
            <div className="text-[10px] font-bold text-[#F5B942] mb-1">03. SAFETY CHECK</div>
            <div className="font-semibold text-[#F8FAFC]">Constraint Model</div>
            <div className="text-[10px] text-[#A9B8C8] mt-1">Verify ampacity, thermal & voltage limits</div>
          </div>

          <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E] flex flex-col justify-between">
            <div className="text-[10px] font-bold text-[#35C99A] mb-1">04. ALGORITHM</div>
            <div className="font-semibold text-[#F8FAFC]">Route Generation</div>
            <div className="text-[10px] text-[#A9B8C8] mt-1">Compute minimal-loss tie-line path</div>
          </div>

          <div className="bg-[#1D3045] p-3 rounded-lg border border-[#35C99A]/40 flex flex-col justify-between bg-[#35C99A]/5">
            <div className="text-[10px] font-bold text-[#35C99A] mb-1">05. OPERATOR REVIEW</div>
            <div className="font-semibold text-[#F8FAFC]">Manual Approval</div>
            <div className="text-[10px] text-[#A9B8C8] mt-1">Human-in-the-loop authorization</div>
          </div>

          <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E] flex flex-col justify-between">
            <div className="text-[10px] font-bold text-[#20A99E] mb-1">06. TELEMETRY LOG</div>
            <div className="font-semibold text-[#F8FAFC]">Simulated Dispatch</div>
            <div className="text-[10px] text-[#A9B8C8] mt-1">Record audit trail & monitor load</div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5">
          <div className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">Available Surplus Power</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#35C99A]">472.0</span>
            <span className="text-xs font-semibold text-[#A9B8C8]">kW</span>
          </div>
          <p className="text-[11px] text-[#A9B8C8] mt-1">FDR-04 (Residential) & FDR-01</p>
        </div>

        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5">
          <div className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">Active Local Deficit</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#F16F75]">-54.0</span>
            <span className="text-xs font-semibold text-[#A9B8C8]">kW</span>
          </div>
          <p className="text-[11px] text-[#A9B8C8] mt-1">Heavy Industrial Estate (FDR-03)</p>
        </div>

        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5">
          <div className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">Inter-Tie Available Headroom</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#20A99E]">346.0</span>
            <span className="text-xs font-semibold text-[#A9B8C8]">kW</span>
          </div>
          <p className="text-[11px] text-[#A9B8C8] mt-1">Tie-Breaker TB-04 Capacity: 400 kW</p>
        </div>

        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5">
          <div className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">Pending Recommendations</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#F5B942]">{pendingCount}</span>
            <span className="text-xs font-semibold text-[#A9B8C8]">Transfers</span>
          </div>
          <p className="text-[11px] text-[#A9B8C8] mt-1">{approvedCount} Transfers Completed/Active</p>
        </div>
      </div>

      {/* Main Roster of Transfer Recommendations */}
      <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-base font-bold text-[#F8FAFC] flex items-center gap-2">
              <ArrowLeftRight className="w-4 h-4 text-[#20A99E]" />
              Inter-Feeder Transfer Recommendations & Status
            </h2>
            <p className="text-xs text-[#A9B8C8]">
              Automated topology proposals with distinct transfer status and deficit resolution tracking
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 self-start">
            <button
              onClick={() => setFilter('ALL')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                filter === 'ALL'
                  ? 'bg-[#20A99E] text-[#101C2C] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              All ({transfers.length})
            </button>
            <button
              onClick={() => setFilter('PENDING_APPROVAL')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                filter === 'PENDING_APPROVAL'
                  ? 'bg-[#F5B942] text-[#101C2C] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              Pending ({pendingCount})
            </button>
            <button
              onClick={() => setFilter('COMPLETED')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                filter === 'COMPLETED'
                  ? 'bg-[#35C99A] text-[#101C2C] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              Completed
            </button>
            <button
              onClick={() => setFilter('ACTIVE_TRANSFER')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                filter === 'ACTIVE_TRANSFER'
                  ? 'bg-[#20A99E] text-[#101C2C] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              Active
            </button>
            <button
              onClick={() => setFilter('REJECTED')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                filter === 'REJECTED'
                  ? 'bg-[#F16F75] text-[#F8FAFC] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              Rejected
            </button>
          </div>
        </div>

        {/* Transfer Cards Grid */}
        <div className="space-y-4">
          {filteredTransfers.map((item) => {
            const isPending = item.status === 'PENDING_APPROVAL';
            const isCompleted = item.status === 'COMPLETED';
            const isActive = item.status === 'ACTIVE_TRANSFER';

            return (
              <div
                key={item.id}
                className={`p-4 rounded-xl border transition-all ${
                  isPending
                    ? 'bg-[#1D3045] border-[#F5B942]/50 shadow-md'
                    : isCompleted || isActive
                    ? 'bg-[#1D3045]/80 border-[#35C99A]/30'
                    : 'bg-[#1D3045]/40 border-[#34495E]'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left: Transfer Details */}
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="font-mono text-xs font-bold text-[#20A99E]">{item.id}</span>
                      <span className="text-[10px] text-[#A9B8C8] font-mono flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {item.timestamp}
                      </span>

                      {/* SEPARATE FIELD 1: Transfer Status */}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                          isPending
                            ? 'bg-[#F5B942]/15 text-[#F5B942] border-[#F5B942]/30'
                            : isCompleted
                            ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30'
                            : isActive
                            ? 'bg-[#20A99E]/15 text-[#20A99E] border-[#20A99E]/30'
                            : 'bg-[#F16F75]/15 text-[#F16F75] border-[#F16F75]/30'
                        }`}
                      >
                        STATUS: {item.status.replace('_', ' ')}
                      </span>

                      {/* SEPARATE FIELD 2: Deficit Resolution Status */}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                          item.deficitResolution === 'FULLY_RESOLVED'
                            ? 'bg-[#35C99A]/20 text-[#35C99A] border-[#35C99A]/40'
                            : item.deficitResolution === 'PARTIALLY_RESOLVED'
                            ? 'bg-[#F5B942]/20 text-[#F5B942] border-[#F5B942]/40'
                            : 'bg-[#F16F75]/20 text-[#F16F75] border-[#F16F75]/40'
                        }`}
                      >
                        DEFICIT: {item.deficitResolution.replace('_', ' ')}
                      </span>
                    </div>

                    {/* Routing Path & Deficit Comparison */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div className="bg-[#101C2C] p-2.5 rounded-lg border border-[#34495E]">
                        <span className="text-[10px] text-[#35C99A] font-semibold uppercase">Surplus Source:</span>
                        <p className="text-xs font-bold text-[#F8FAFC]">{item.surplusLocality}</p>
                        <p className="text-[10px] text-[#A9B8C8]">Available: +{item.availableSurplusKw} kW</p>
                      </div>

                      <div className="bg-[#101C2C] p-2.5 rounded-lg border border-[#34495E]">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-[#F16F75] font-semibold uppercase">Target Deficit Feeder:</span>
                          <span className="text-[10px] font-mono text-[#F8FAFC]">
                            Remaining: <strong className={item.remainingDeficitKw === 0 ? 'text-[#35C99A]' : 'text-[#F16F75]'}>{item.remainingDeficitKw} kW</strong>
                          </span>
                        </div>
                        <p className="text-xs font-bold text-[#F8FAFC]">{item.shortageLocality}</p>
                        <p className="text-[10px] text-[#A9B8C8]">
                          Initial Deficit: -{item.shortageDemandKw} kW • Transfer: +{item.recommendedTransferKw} kW
                        </p>
                      </div>
                    </div>

                    {/* Network Route & Constraints Verification */}
                    <div className="text-xs text-[#A9B8C8] space-y-1">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-[#F8FAFC]">Switching Route:</span>
                        <span className="font-mono text-[#A9B8C8]">{item.transferRoute}</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] pt-1">
                        <span>
                          Transfer Power: <strong className="text-[#35C99A] font-mono">{item.recommendedTransferKw} kW</strong>
                        </span>
                        <span>
                          Tie Capacity: <strong className="text-[#F8FAFC] font-mono">{item.tieLineCapacityKw} kW</strong>
                        </span>
                        <span>
                          Voltage Impact: <strong className="text-[#F8FAFC] font-mono">{item.voltageImpactDeltaV}V</strong>
                        </span>
                        <span>
                          Thermal Margin: <strong className="text-[#20A99E] font-mono">{item.thermalHeadroomPercent}%</strong>
                        </span>
                      </div>
                    </div>

                    {/* Approval Attribution if done */}
                    {item.approvedBy && (
                      <div className="text-[10px] text-[#35C99A] flex items-center gap-1.5 pt-1">
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>
                          {item.approvedBy} at <strong className="font-mono">{item.approvedAt}</strong>
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Right: Operator Decision Action Controls */}
                  <div className="flex sm:flex-col items-center justify-end gap-2 shrink-0 border-t sm:border-t-0 sm:border-l border-[#34495E] pt-3 sm:pt-0 sm:pl-4">
                    {isPending ? (
                      <>
                        <button
                          onClick={() => handleApprove(item.id)}
                          className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-[#35C99A] hover:bg-[#2db589] text-[#101C2C] font-bold text-xs transition-colors shadow-md cursor-pointer"
                        >
                          <Check className="w-4 h-4" />
                          <span>Approve Transfer</span>
                        </button>
                        <button
                          onClick={() => handleReject(item.id)}
                          className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#101C2C] hover:bg-[#F16F75]/20 text-[#F16F75] border border-[#F16F75]/40 font-semibold text-xs transition-colors cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </>
                    ) : (
                      <div className="text-right py-2 space-y-1">
                        <span className="text-xs font-semibold text-[#A9B8C8] block">
                          {isCompleted ? 'Transfer Completed' : isActive ? 'Active Transfer' : 'Proposal Closed'}
                        </span>
                        <span className="text-[11px] font-mono text-[#35C99A] block">
                          {item.deficitResolution === 'FULLY_RESOLVED' ? 'Deficit Eliminated' : `${item.remainingDeficitKw} kW Deficit Remaining`}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================= */}
      {/* INTERACTIVE GRID TOPOLOGY CONSTRAINT SAFETY MATRIX        */}
      {/* ========================================================= */}
      <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#34495E]">
          <div>
            <h2 className="text-base font-bold text-[#F8FAFC] flex items-center gap-2">
              <Network className="w-4 h-4 text-[#20A99E]" />
              Interactive Grid Topology Constraint Matrix
            </h2>
            <p className="text-xs text-[#A9B8C8]">
              Graph-based routing verification, thermal limits, voltage regulation, and equipment status checks
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-[11px] font-mono text-[#A9B8C8]">Checked: {lastCheckTimestamp}</span>
            <button
              onClick={handleResetConstraints}
              className="p-1.5 rounded-lg bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E] text-xs transition-colors"
              title="Reset Constraint Parameters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Interactive Constraint Simulation Controls Panel */}
        <div className="bg-[#101C2C] p-4 rounded-xl border border-[#34495E] space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-[#20A99E] uppercase tracking-wider">
            <Sliders className="w-3.5 h-3.5" />
            Simulation Parameters & Network Conditions
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
            {/* Source Feeder */}
            <div>
              <label className="text-[#A9B8C8] block mb-1 font-medium">Source Feeder (Surplus)</label>
              <select
                value={sourceFeeder}
                onChange={(e) => setSourceFeeder(e.target.value as any)}
                className="w-full bg-[#1D3045] border border-[#34495E] rounded-lg p-2 text-[#F8FAFC] text-xs font-medium focus:border-[#20A99E] outline-none"
              >
                <option value="FDR-04">FDR-04 (North Residential, +186 kW)</option>
                <option value="FDR-01">FDR-01 (Tech Park, +172 kW)</option>
                <option value="FDR-05">FDR-05 (Metro Transit, +72 kW)</option>
                <option value="FDR-06">FDR-06 (Healthcare - Isolated)</option>
              </select>
            </div>

            {/* Destination Feeder */}
            <div>
              <label className="text-[#A9B8C8] block mb-1 font-medium">Destination Feeder (Shortage)</label>
              <select
                value={destinationFeeder}
                onChange={(e) => setDestinationFeeder(e.target.value as any)}
                className="w-full bg-[#1D3045] border border-[#34495E] rounded-lg p-2 text-[#F8FAFC] text-xs font-medium focus:border-[#20A99E] outline-none"
              >
                <option value="FDR-03">FDR-03 (Heavy Industrial, -54 kW)</option>
                <option value="FDR-02">FDR-02 (Commercial Core, -35 kW)</option>
              </select>
            </div>

            {/* Transfer Amount Input */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-[#A9B8C8] font-medium">Transfer Power (kW)</label>
                <span className="font-mono font-bold text-[#35C99A]">{transferKwInput} kW</span>
              </div>
              <input
                type="range"
                min="10"
                max="450"
                step="10"
                value={transferKwInput}
                onChange={(e) => setTransferKwInput(Number(e.target.value))}
                className="w-full accent-[#20A99E] bg-[#152538] rounded-lg cursor-pointer h-2 mt-2"
              />
              <div className="flex justify-between text-[10px] text-[#A9B8C8] mt-1">
                <span>10 kW</span>
                <span>400 kW Limit</span>
                <span>450 kW</span>
              </div>
            </div>

            {/* Tie Breaker TB-04 Toggle */}
            <div>
              <label className="text-[#A9B8C8] block mb-1 font-medium">Tie Breaker TB-04</label>
              <select
                value={tieBreakerTB04State}
                onChange={(e) => setTieBreakerTB04State(e.target.value as any)}
                className={`w-full border rounded-lg p-2 text-xs font-semibold outline-none ${
                  tieBreakerTB04State === 'CLOSED'
                    ? 'bg-[#1D3045] text-[#35C99A] border-[#35C99A]/40'
                    : 'bg-[#1D3045] text-[#F16F75] border-[#F16F75]/40'
                }`}
              >
                <option value="CLOSED">CLOSED (Operational)</option>
                <option value="OPEN">OPEN / FAULT (Isolated)</option>
              </select>
            </div>

            {/* Bus Coupler BC-02 Toggle */}
            <div>
              <label className="text-[#A9B8C8] block mb-1 font-medium">Bus Coupler BC-02</label>
              <select
                value={busCouplerBC02State}
                onChange={(e) => setBusCouplerBC02State(e.target.value as any)}
                className={`w-full border rounded-lg p-2 text-xs font-semibold outline-none ${
                  busCouplerBC02State === 'ONLINE'
                    ? 'bg-[#1D3045] text-[#35C99A] border-[#35C99A]/40'
                    : 'bg-[#1D3045] text-[#F5B942] border-[#F5B942]/40'
                }`}
              >
                <option value="ONLINE">ONLINE (Healthy)</option>
                <option value="MAINTENANCE">MAINTENANCE (Offline)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-[#34495E]/60">
            <div className="text-[11px] text-[#A9B8C8] flex items-center gap-2">
              <span className="font-semibold text-[#F8FAFC]">Selected Route Path:</span>
              <span className="font-mono text-[#20A99E]">{constraintEvaluation.pathSummary}</span>
            </div>

            <button
              onClick={handleRunConstraintCheck}
              className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-[#20A99E] hover:bg-[#1b8e85] text-[#101C2C] font-bold text-xs transition-colors shadow-sm cursor-pointer self-start sm:self-auto"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Run Constraint Check</span>
            </button>
          </div>
        </div>

        {/* Overall Synthesis Banner */}
        <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
          constraintEvaluation.overallResult === 'SAFE TO RECOMMEND'
            ? 'bg-[#35C99A]/10 border-[#35C99A]/40'
            : constraintEvaluation.overallResult === 'REQUIRES OPERATOR REVIEW'
            ? 'bg-[#F5B942]/10 border-[#F5B942]/40'
            : 'bg-[#F16F75]/10 border-[#F16F75]/40'
        }`}>
          <div className="flex items-center gap-3">
            {constraintEvaluation.overallResult === 'SAFE TO RECOMMEND' ? (
              <CheckCircle2 className="w-6 h-6 text-[#35C99A] shrink-0" />
            ) : (
              <AlertTriangle className={`w-6 h-6 shrink-0 ${
                constraintEvaluation.overallResult === 'REQUIRES OPERATOR REVIEW' ? 'text-[#F5B942]' : 'text-[#F16F75]'
              }`} />
            )}
            <div>
              <div className="text-xs font-bold text-[#A9B8C8] uppercase tracking-wider">
                Overall Topology Synthesis Result
              </div>
              <div className={`text-base font-extrabold tracking-tight ${
                constraintEvaluation.overallResult === 'SAFE TO RECOMMEND'
                  ? 'text-[#35C99A]'
                  : constraintEvaluation.overallResult === 'REQUIRES OPERATOR REVIEW'
                  ? 'text-[#F5B942]'
                  : 'text-[#F16F75]'
              }`}>
                {constraintEvaluation.overallResult}
              </div>
            </div>
          </div>

          <div className="text-xs text-[#A9B8C8] max-w-md sm:text-right">
            {constraintEvaluation.overallResult === 'SAFE TO RECOMMEND' && (
              <span>All 8 safety constraints validated. Proposed power routing is electrically safe and within statutory margins.</span>
            )}
            {constraintEvaluation.overallResult === 'REQUIRES OPERATOR REVIEW' && (
              <span>One or more non-critical margins are elevated. Requires dispatcher inspection of voltage sag and thermal parameters.</span>
            )}
            {constraintEvaluation.overallResult === 'TRANSFER NOT FEASIBLE' && (
              <span>Critical safety constraints violated. Transfer is blocked by topological isolation or equipment status interlock.</span>
            )}
          </div>
        </div>

        {/* 8 Constraint Cards Grid (Dynamic PASS, WARNING, FAIL) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {constraintEvaluation.results.map((item) => (
            <div
              key={item.title}
              className={`p-3.5 rounded-lg border flex flex-col justify-between ${
                item.status === 'PASS'
                  ? 'bg-[#1D3045] border-[#34495E]'
                  : item.status === 'WARNING'
                  ? 'bg-[#1D3045] border-[#F5B942]/50'
                  : 'bg-[#1D3045] border-[#F16F75]/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-semibold text-[#F8FAFC]">{item.title}</span>
                  <span
                    className={`font-bold text-[10px] px-1.5 py-0.5 rounded border ${
                      item.status === 'PASS'
                        ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30'
                        : item.status === 'WARNING'
                        ? 'bg-[#F5B942]/15 text-[#F5B942] border-[#F5B942]/30'
                        : 'bg-[#F16F75]/15 text-[#F16F75] border-[#F16F75]/30'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
                <div className="font-mono text-xs font-bold text-[#A9B8C8] mb-1.5">
                  {item.metric}
                </div>
                <p className="text-[10px] text-[#A9B8C8] leading-relaxed">
                  {item.reason}
                </p>
              </div>

              <div className="mt-2 pt-2 border-t border-[#34495E]/50 flex items-center justify-between text-[9px] text-[#A9B8C8] uppercase font-mono">
                <span>Domain</span>
                <span>{item.category}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Technical Validation Disclaimer */}
        <div className="p-3 bg-[#101C2C] border border-[#34495E] rounded-lg flex items-center gap-3 text-xs text-[#A9B8C8]">
          <ShieldCheck className="w-4 h-4 text-[#20A99E] shrink-0" />
          <span>
            <strong>ENGINEERING NOTE:</strong> This frontend simulation models graph connectivity and IEEE-738 empirical thermal formulas. It serves as an operator decision-support tool and does not substitute full AC Newton-Raphson load flow studies.
          </span>
        </div>
      </div>
    </div>
  );
};
