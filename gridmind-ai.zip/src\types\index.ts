export type StatusType = 'normal' | 'warning' | 'critical' | 'info';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'Grid Dispatcher' | 'Lead Dispatcher' | 'Substation Engineer' | 'Utility Analyst' | 'System Admin';
  avatar?: string;
}

export interface MetricSummary {
  currentConsumptionKw: number;
  predictedDemandKw: number;
  activeTransformers: number;
  totalTransformers: number;
  activeFeeders: number;
  totalFeeders: number;
  gridHealthScore: number;
  frequencyHz: number;
  voltageKv: number;
  powerFactor: number;
  activeAlertsCount: number;
  criticalAlertsCount: number;
  warningAlertsCount: number;
}

export interface HourlyConsumption {
  time: string;
  consumption: number; // in kW
  predicted?: number; // in kW
  baseline?: number;
  isPeak?: boolean;
}

export interface LocalityConsumption {
  id: string;
  name: string;
  currentKw: number;
  percentage: number;
  trend: 'up' | 'down' | 'stable';
  feederId: string;
  transformerId: string;
}

export interface TransformerItem {
  id: string;
  name: string;
  substation: string;
  capacityKva: number;
  currentLoadKva: number;
  loadingPercentage: number;
  voltageV: number;
  currentA: number;
  oilTempC: number;
  windingTempC: number;
  status: StatusType;
  coolingStatus: 'AUTO' | 'ON' | 'STANDBY';
  tapPosition: number;
  lastInspection: string;
}

export interface FeederItem {
  id: string;
  name: string;
  substation: string;
  locality: string;
  demandKw: number;
  voltageKv: number;
  currentA: number;
  feederLoadingPercentage: number;
  powerFactor: number;
  status: 'ONLINE' | 'STANDBY' | 'TRIPPED';
  breakerState: 'CLOSED' | 'OPEN';
  protectionStatus: 'NORMAL' | 'ARMED' | 'TRIPPED';
}

export interface AlertItem {
  id: string;
  title: string;
  description: string;
  severity: StatusType;
  timestamp: string;
  sourceType: 'TRANSFORMER' | 'FEEDER' | 'SUBSTATION' | 'AI_MODEL' | 'SYSTEM';
  sourceId: string;
  sourceName: string;
  isAcknowledged: boolean;
  isResolved: boolean;
  isRead?: boolean;
  acknowledgedBy?: string;
  resolvedAt?: string;
  readAt?: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  details: string;
  timestamp: string;
  user: string;
  type: 'telemetry' | 'ai' | 'alert' | 'switch' | 'system';
}

export interface PredictionDataPoint {
  time: string;
  actual?: number;
  predicted: number;
  upperBound: number;
  lowerBound: number;
}

export interface HistoricalRecord {
  id: string;
  date: string;
  time: string;
  locality: string;
  consumptionKw: number;
  peakStatus: 'Normal' | 'Peak' | 'Off-Peak';
  powerFactor: number;
  frequencyHz: number;
}

// Energy Balance Types
export interface EnergyBalanceMetric {
  timestamp: string;
  incomingPowerKw: number;
  consumerDemandKw: number;
  technicalLossesKw: number;
  unexplainedDifferenceKw: number;
  netAvailableSurplusKw: number;
  technicalLossBreakdown: {
    transformerLossesKw: number;
    feederLineLossesKw: number;
    dielectricLossesKw: number;
  };
}

export interface LocalityEnergyBalance {
  localityId: string;
  localityName: string;
  feederName: string;
  supplyAllocatedKw: number;
  demandMeasuredKw: number;
  lossesKw: number;
  balanceKw: number;
  status: 'SURPLUS' | 'BALANCED' | 'SHORTAGE';
}

// Surplus Electricity Management Types
export type TransferStatus = 'PENDING_APPROVAL' | 'APPROVED' | 'TRANSFER_INITIATED' | 'ACTIVE_TRANSFER' | 'COMPLETED' | 'REJECTED';
export type DeficitResolution = 'FULLY_RESOLVED' | 'PARTIALLY_RESOLVED' | 'UNRESOLVED';

export interface SurplusTransferItem {
  id: string;
  timestamp: string;
  surplusLocality: string;
  surplusFeeder: string;
  availableSurplusKw: number;
  shortageLocality: string;
  shortageFeeder: string;
  shortageDemandKw: number;
  recommendedTransferKw: number;
  transferRoute: string;
  tieLineCapacityKw: number;
  estimatedLossIncreaseKw: number;
  voltageImpactDeltaV: number;
  thermalHeadroomPercent: number;
  status: TransferStatus;
  deficitResolution: DeficitResolution;
  remainingDeficitKw: number;
  approvedBy?: string;
  approvedAt?: string;
}

// Battery Energy Storage System (BESS) Types
export interface BessSystemState {
  id: string;
  name: string;
  substation: string;
  totalCapacityKwh: number;
  currentEnergyKwh: number;
  stateOfChargePct: number;
  stateOfHealthPct: number;
  currentPowerKw: number; // positive = discharging, negative = charging, 0 = idle
  maxChargePowerKw: number;
  maxDischargePowerKw: number;
  cellTemperatureC: number;
  operatingMode: 'AUTO_AI' | 'MANUAL_CHARGE' | 'MANUAL_DISCHARGE' | 'STANDBY';
  cycleCount: number;
  efficiencyPct: number;
  inverterStatus: 'OPTIMAL' | 'SYNCED' | 'DERATED' | 'OFFLINE';
}

export interface BessHistoryEvent {
  id: string;
  timestamp: string;
  event: string;
  type: 'CHARGE' | 'DISCHARGE' | 'STANDBY' | 'TRIP';
  powerKw: number;
  durationMinutes: number;
  energyKwh: number;
  initialSocPct: number;
  finalSocPct: number;
  dispatcher: string;
}

// What-If Simulation Types
export interface WhatIfSimulationParams {
  demandChangePct: number;
  solarPvGenerationKw: number;
  industrialActivityPct: number;
  ambientTemperatureC: number;
  gridSupplyKw: number;
  bessDispatchKw: number;
}

