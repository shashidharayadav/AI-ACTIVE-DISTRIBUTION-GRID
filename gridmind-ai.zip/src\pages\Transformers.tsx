import React, { useState } from 'react';
import {
  Cpu,
  Thermometer,
  Activity,
  AlertTriangle,
  Fan,
  Eye,
  Search
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { TransformerLoadingChart } from '../components/charts/TransformerLoadingChart';
import { mockTransformers } from '../data/mockData';
import type { TransformerItem } from '../types';

export const Transformers: React.FC = () => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTransformer, setSelectedTransformer] = useState<TransformerItem | null>(null);

  const filteredTransformers = mockTransformers.filter((tr) => {
    const matchesStatus = filterStatus === 'ALL' || tr.status === filterStatus;
    const matchesSearch =
      tr.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tr.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tr.substation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            Transformer Fleet Thermal & Loading Monitoring
          </h2>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Real-time kVA capacity utilization, winding hotspot telemetry, and cooling control
          </p>
        </div>

        {/* Search & Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#A9B8C8]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search transformer or substation..."
              className="pl-8 pr-3 py-1.5 rounded-lg bg-[#152538] border border-[#34495E] text-xs text-[#F8FAFC] placeholder-[#A9B8C8]/50 focus:outline-none focus:border-[#20A99E] w-48 sm:w-60"
            />
          </div>

          <div className="flex items-center gap-1 bg-[#152538] p-1 rounded-lg border border-[#34495E]">
            {['ALL', 'normal', 'warning', 'critical'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 rounded text-xs font-semibold uppercase transition-all ${
                  filterStatus === st
                    ? 'bg-[#20A99E] text-[#101C2C]'
                    : 'text-[#A9B8C8] hover:text-[#F8FAFC]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Fleet Summary KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Monitored Fleet Capacity"
          value="8,500"
          unit="kVA"
          icon={Cpu}
          subtitle="6 Primary Substation Units"
          accent="teal"
        />
        <MetricCard
          title="Average Fleet Loading"
          value="73.0%"
          unit="Nominal"
          icon={Activity}
          trend={{ value: '+3.1%', direction: 'up', label: 'vs last shift' }}
          accent="emerald"
        />
        <MetricCard
          title="Units in Warning Zone (>80%)"
          value="2"
          unit="Transformers"
          icon={AlertTriangle}
          subtitle="TR-102 (85%) & TR-105 (83%)"
          accent="amber"
        />
        <MetricCard
          title="Max Winding Temperature"
          value="79.5°C"
          unit="TR-102"
          icon={Thermometer}
          subtitle="Forced air cooling engaged"
          accent="amber"
        />
      </div>

      {/* Loading Overview Bar Chart */}
      <Card
        title="Fleet Capacity Utilization vs Alert Thresholds"
        subtitle="Amber threshold at 80% capacity; Coral Red critical at 90%"
        highlight="teal"
      >
        <TransformerLoadingChart data={mockTransformers} height={260} />
      </Card>

      {/* Transformer Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTransformers.map((tr) => {
          const isWarning = tr.loadingPercentage >= 80;
          const isCritical = tr.loadingPercentage >= 90;

          return (
            <div
              key={tr.id}
              className={`rounded-xl bg-[#1D3045] border transition-all duration-200 p-5 flex flex-col justify-between ${
                isCritical
                  ? 'border-[#F16F75]/60 shadow-[0_0_20px_-5px_rgba(241,111,117,0.3)]'
                  : isWarning
                  ? 'border-[#F5B942]/60 shadow-[0_0_20px_-5px_rgba(245,185,66,0.2)]'
                  : 'border-[#34495E] hover:border-[#20A99E]/50'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-mono text-[#20A99E] font-semibold">{tr.id}</span>
                    <h3 className="text-sm font-bold text-[#F8FAFC]">{tr.name}</h3>
                    <p className="text-[11px] text-[#A9B8C8] line-clamp-1">{tr.substation}</p>
                  </div>
                  <StatusBadge status={tr.status} size="sm" />
                </div>

                {/* Loading Progress Bar */}
                <div className="my-4">
                  <div className="flex justify-between items-baseline text-xs mb-1">
                    <span className="text-[#A9B8C8]">Capacity Loading:</span>
                    <span
                      className={`text-base font-bold ${
                        isCritical
                          ? 'text-[#F16F75]'
                          : isWarning
                          ? 'text-[#F5B942]'
                          : 'text-[#35C99A]'
                      }`}
                    >
                      {tr.loadingPercentage}%
                    </span>
                  </div>
                  <div className="h-2 w-full bg-[#152538] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isCritical
                          ? 'bg-[#F16F75]'
                          : isWarning
                          ? 'bg-[#F5B942]'
                          : 'bg-[#35C99A]'
                      }`}
                      style={{ width: `${Math.min(tr.loadingPercentage, 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-[#A9B8C8] mt-1">
                    <span>{tr.currentLoadKva} kVA active</span>
                    <span>Rating: {tr.capacityKva} kVA</span>
                  </div>
                </div>

                {/* Key Electrical & Thermal Metrics */}
                <div className="grid grid-cols-2 gap-2 text-xs py-2 border-y border-[#34495E]/60 my-3">
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] text-[#A9B8C8] block">Bus Voltage</span>
                    <span className="font-semibold text-[#F8FAFC]">
                      {(tr.voltageV / 1000).toFixed(2)} kV
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] text-[#A9B8C8] block">Phase Current</span>
                    <span className="font-semibold text-[#F8FAFC]">{tr.currentA} A</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] text-[#A9B8C8] block">Top Oil Temp</span>
                    <span
                      className={`font-semibold ${
                        tr.oilTempC > 65 ? 'text-[#F5B942]' : 'text-[#35C99A]'
                      }`}
                    >
                      {tr.oilTempC}°C
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] text-[#A9B8C8] block">Winding Hotspot</span>
                    <span
                      className={`font-semibold ${
                        tr.windingTempC > 75 ? 'text-[#F5B942]' : 'text-[#35C99A]'
                      }`}
                    >
                      {tr.windingTempC}°C
                    </span>
                  </div>
                </div>

                {/* Cooling Status */}
                <div className="flex items-center justify-between text-xs text-[#A9B8C8] my-2">
                  <div className="flex items-center gap-1.5">
                    <Fan
                      className={`w-3.5 h-3.5 ${
                        tr.coolingStatus === 'ON' ? 'text-[#35C99A] animate-spin' : 'text-[#A9B8C8]'
                      }`}
                    />
                    <span>Cooling: <strong>{tr.coolingStatus}</strong></span>
                  </div>
                  <span>Tap Pos: <strong>{tr.tapPosition}</strong></span>
                </div>
              </div>

              {/* Inspector Action Button */}
              <div className="mt-4 pt-3 border-t border-[#34495E]">
                <Button
                  variant="secondary"
                  size="sm"
                  icon={Eye}
                  className="w-full"
                  onClick={() => setSelectedTransformer(tr)}
                >
                  Inspect Asset Telemetry
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Transformer Inspector Detail Modal */}
      {selectedTransformer && (
        <Modal
          isOpen={!!selectedTransformer}
          onClose={() => setSelectedTransformer(null)}
          title={`SCADA Asset Inspector: ${selectedTransformer.id}`}
          subtitle={selectedTransformer.name}
          maxWidth="xl"
        >
          <div className="space-y-4 text-xs">
            {/* Status Banner */}
            <div className="p-3.5 rounded-xl bg-[#152538] border border-[#34495E] flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#A9B8C8] uppercase tracking-wider block">
                  Operating Status
                </span>
                <span className="text-sm font-bold text-[#F8FAFC]">
                  {selectedTransformer.loadingPercentage}% Rated Capacity
                </span>
              </div>
              <StatusBadge status={selectedTransformer.status} size="lg" />
            </div>

            {/* Technical Specifications */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
                <span className="text-[#A9B8C8] text-[10px] block">Nameplate Capacity</span>
                <span className="text-sm font-bold text-[#F8FAFC]">
                  {selectedTransformer.capacityKva} kVA
                </span>
              </div>
              <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
                <span className="text-[#A9B8C8] text-[10px] block">Current Load</span>
                <span className="text-sm font-bold text-[#20A99E]">
                  {selectedTransformer.currentLoadKva} kVA
                </span>
              </div>
              <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
                <span className="text-[#A9B8C8] text-[10px] block">Nominal Voltage</span>
                <span className="text-sm font-bold text-[#F8FAFC]">
                  {selectedTransformer.voltageV} V
                </span>
              </div>
              <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
                <span className="text-[#A9B8C8] text-[10px] block">Secondary Current</span>
                <span className="text-sm font-bold text-[#F8FAFC]">
                  {selectedTransformer.currentA} A
                </span>
              </div>
              <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
                <span className="text-[#A9B8C8] text-[10px] block">Top Oil Temp</span>
                <span className="text-sm font-bold text-[#F5B942]">
                  {selectedTransformer.oilTempC}°C
                </span>
              </div>
              <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
                <span className="text-[#A9B8C8] text-[10px] block">Winding Hotspot</span>
                <span className="text-sm font-bold text-[#F16F75]">
                  {selectedTransformer.windingTempC}°C
                </span>
              </div>
            </div>

            {/* Dissolved Gas Analysis (DGA) & Health Diagnostics */}
            <div className="p-3.5 rounded-xl bg-[#152538] border border-[#34495E]">
              <h5 className="text-xs font-semibold text-[#F8FAFC] mb-2">
                Dissolved Gas Analysis (DGA) & Insulation Health
              </h5>
              <div className="grid grid-cols-3 gap-2 text-[11px]">
                <div>
                  <span className="text-[#A9B8C8] block">Hydrogen (H₂):</span>
                  <span className="font-semibold text-[#35C99A]">12 ppm (Normal)</span>
                </div>
                <div>
                  <span className="text-[#A9B8C8] block">Methane (CH₄):</span>
                  <span className="font-semibold text-[#35C99A]">4 ppm (Normal)</span>
                </div>
                <div>
                  <span className="text-[#A9B8C8] block">Carbon Monoxide:</span>
                  <span className="font-semibold text-[#35C99A]">180 ppm (Normal)</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="secondary" size="sm" onClick={() => setSelectedTransformer(null)}>
                Close Inspector
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
