import React, { useState } from 'react';
import {
  Download,
  Printer,
  CheckCircle2,
  Zap,
  BrainCircuit,
  Layers
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { MetricCard } from '../components/common/MetricCard';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { ConsumptionChart } from '../components/charts/ConsumptionChart';
import { TransformerLoadingChart } from '../components/charts/TransformerLoadingChart';
import {
  mockHourlyConsumption,
  mockTransformers,
  mockLocalityConsumption,
  mockEnergyBalanceSeries,
  mockSurplusTransfers,
  mockBessHistory
} from '../data/mockData';

export const Reports: React.FC = () => {
  const [reportType, setReportType] = useState<string>('CONSUMPTION');
  const [dateRange, setDateRange] = useState<string>('7D');
  const [showPdfModal, setShowPdfModal] = useState(false);

  const handleDownloadCsv = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (reportType === 'ENERGY_BALANCE') {
      csvContent += 'Timestamp,Incoming Supply kW,Consumer Demand kW,Technical Losses kW,Usable Surplus kW\n';
      mockEnergyBalanceSeries.forEach((r) => {
        csvContent += `${r.time},${r.incoming},${r.demand},${r.losses},${r.surplus}\n`;
      });
    } else if (reportType === 'SURPLUS') {
      csvContent += 'Transfer ID,Timestamp,Surplus Locality,Shortage Locality,Transfer kW,Tie Route,Status,Approver\n';
      mockSurplusTransfers.forEach((r) => {
        csvContent += `${r.id},${r.timestamp},"${r.surplusLocality}","${r.shortageLocality}",${r.recommendedTransferKw},"${r.transferRoute}",${r.status},"${r.approvedBy || 'N/A'}"\n`;
      });
    } else if (reportType === 'BESS') {
      csvContent += 'Event ID,Timestamp,Event,Type,Power kW,Duration Mins,Energy kWh,Start SOC,Final SOC,Dispatcher\n';
      mockBessHistory.forEach((r) => {
        csvContent += `${r.id},${r.timestamp},"${r.event}",${r.type},${r.powerKw},${r.durationMinutes},${r.energyKwh},${r.initialSocPct}%,${r.finalSocPct}%,"${r.dispatcher}"\n`;
      });
    } else {
      csvContent += 'Timestamp,Active Load kW,Predicted Demand kW,Baseline kW,Status\n';
      mockHourlyConsumption.forEach((row) => {
        csvContent += `${row.time},${row.consumption},${row.predicted || ''},${row.baseline || ''},${
          row.isPeak ? 'PEAK' : 'NORMAL'
        }\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `gridmind_report_${reportType.toLowerCase()}_${dateRange}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            Grid Reports & Analytical Intelligence
          </h2>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Auditable dispatch logs, Random Forest forecast validation, and asset degradation metrics
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            icon={Printer}
            onClick={() => setShowPdfModal(true)}
          >
            Print / PDF Preview
          </Button>
          <Button
            variant="primary"
            size="sm"
            icon={Download}
            onClick={handleDownloadCsv}
          >
            Export CSV Report
          </Button>
        </div>
      </div>

      {/* Filter Ribbon */}
      <div className="rounded-xl bg-[#1D3045] border border-[#34495E] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Report Category Selector */}
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'CONSUMPTION', label: 'Electricity Consumption' },
            { id: 'PREDICTION', label: 'AI Demand Accuracy' },
            { id: 'ENERGY_BALANCE', label: 'Energy Balance & Losses' },
            { id: 'SURPLUS', label: 'Surplus & Transfers' },
            { id: 'BESS', label: 'BESS Storage Cycles' },
            { id: 'TRANSFORMERS', label: 'Transformer Fleet' },
            { id: 'FEEDERS', label: 'Feeder Load & Losses' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setReportType(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                reportType === cat.id
                  ? 'bg-[#20A99E] text-[#101C2C]'
                  : 'text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Date Range Selector */}
        <div className="flex flex-wrap items-center gap-1.5 bg-[#152538] p-1 rounded-lg border border-[#34495E]">
          {[
            { id: '24H', label: '24 Hours' },
            { id: '7D', label: '7 Days' },
            { id: '30D', label: '30 Days' },
            { id: 'QTD', label: 'Quarter' },
          ].map((rng) => (
            <button
              key={rng.id}
              onClick={() => setDateRange(rng.id)}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition-all ${
                dateRange === rng.id
                  ? 'bg-[#20A99E] text-[#101C2C]'
                  : 'text-[#A9B8C8] hover:text-[#F8FAFC]'
              }`}
            >
              {rng.label}
            </button>
          ))}
        </div>
      </div>

      {/* Report Dynamic Content */}
      {reportType === 'CONSUMPTION' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard
              title="Aggregated Energy Delivered"
              value="688.5"
              unit="MWh"
              icon={Zap}
              subtitle="7-day operational cumulative"
              accent="teal"
            />
            <MetricCard
              title="Peak Observed Demand"
              value="5,490"
              unit="kW"
              icon={Layers}
              subtitle="Recorded 19:00 PM (Residential Peak)"
              accent="amber"
            />
            <MetricCard
              title="Average Power Factor"
              value="0.98"
              unit="Optimal"
              icon={CheckCircle2}
              subtitle="Zero utility penalty incurred"
              accent="emerald"
            />
          </div>

          <Card
            title="Consolidated Consumption Profile"
            subtitle="Hourly load curve across all 6 distribution zones"
            highlight="teal"
          >
            <ConsumptionChart data={mockHourlyConsumption} height={320} showBaseline={true} />
          </Card>
        </div>
      )}

      {reportType === 'PREDICTION' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard
              title="Model Accuracy (R² Score)"
              value="0.978"
              unit="Score"
              icon={BrainCircuit}
              subtitle="Explained variance in test set"
              accent="violet"
            />
            <MetricCard
              title="Mean Absolute Error (MAE)"
              value="19.8"
              unit="kW"
              icon={Layers}
              subtitle="0.41% average relative residual"
              accent="emerald"
            />
            <MetricCard
              title="Peak Shaving Efficiency"
              value="94.2%"
              unit="Success"
              icon={CheckCircle2}
              subtitle="Battery storage dispatch success"
              accent="teal"
            />
          </div>

          <Card
            title="Random Forest Forecast Verification Log"
            subtitle="Evaluating 15-minute predictive performance against actual ground truth"
            highlight="violet"
          >
            <div className="overflow-x-auto text-xs">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-[#34495E] text-[#A9B8C8] text-[11px] uppercase">
                    <th className="pb-2.5 font-medium">Evaluation Window</th>
                    <th className="pb-2.5 font-medium">Actual Load (kW)</th>
                    <th className="pb-2.5 font-medium">Predicted Load (kW)</th>
                    <th className="pb-2.5 font-medium">Absolute Error (kW)</th>
                    <th className="pb-2.5 font-medium">Percentage Error</th>
                    <th className="pb-2.5 font-medium text-right">Confidence Match</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#34495E]/60">
                  {[
                    { time: '21:00 - 21:30', actual: 4890, pred: 4910, err: 20, pct: '0.41%', match: 'Within 95% CI' },
                    { time: '21:30 - 22:00', actual: 4420, pred: 4440, err: 20, pct: '0.45%', match: 'Within 95% CI' },
                    { time: '22:00 - 22:30', actual: 3950, pred: 3970, err: 20, pct: '0.50%', match: 'Within 95% CI' },
                    { time: '22:30 - 23:00', actual: 4410, pred: 4430, err: 20, pct: '0.45%', match: 'Within 95% CI' },
                  ].map((row) => (
                    <tr key={row.time} className="hover:bg-[#263B50]/30 transition-colors">
                      <td className="py-2.5 font-medium text-[#F8FAFC]">{row.time}</td>
                      <td className="py-2.5 font-semibold text-[#20A99E]">{row.actual} kW</td>
                      <td className="py-2.5 font-semibold text-[#9585F5]">{row.pred} kW</td>
                      <td className="py-2.5 font-mono text-[#F8FAFC]">{row.err} kW</td>
                      <td className="py-2.5 text-[#35C99A] font-semibold">{row.pct}</td>
                      <td className="py-2.5 text-right text-[#35C99A] font-medium">{row.match}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {reportType === 'TRANSFORMERS' && (
        <div className="space-y-6">
          <Card
            title="Transformer Fleet Thermal & Stress Analytics"
            subtitle="Loading percentage vs 80% warning and 90% critical trip lines"
            highlight="teal"
          >
            <TransformerLoadingChart data={mockTransformers} height={280} />
          </Card>
        </div>
      )}

      {reportType === 'FEEDERS' && (
        <div className="space-y-6">
          <Card
            title="Feeder Line Losses & Power Factor Report"
            subtitle="Distribution line technical losses and reactive power distribution"
            highlight="teal"
          >
            <div className="overflow-x-auto text-xs">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-[#34495E] text-[#A9B8C8] text-[11px] uppercase">
                    <th className="pb-2.5 font-medium">Feeder Line</th>
                    <th className="pb-2.5 font-medium">Connected Locality</th>
                    <th className="pb-2.5 font-medium">Delivered (kW)</th>
                    <th className="pb-2.5 font-medium">Estimated I²R Loss</th>
                    <th className="pb-2.5 font-medium">Efficiency</th>
                    <th className="pb-2.5 font-medium text-right">Power Factor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#34495E]/60">
                  {mockLocalityConsumption.map((loc) => (
                    <tr key={loc.id} className="hover:bg-[#263B50]/30 transition-colors">
                      <td className="py-2.5 font-mono text-[#20A99E] font-bold">{loc.feederId}</td>
                      <td className="py-2.5 font-medium text-[#F8FAFC]">{loc.name}</td>
                      <td className="py-2.5 font-semibold text-[#F8FAFC]">{loc.currentKw} kW</td>
                      <td className="py-2.5 font-mono text-[#A9B8C8]">{(loc.currentKw * 0.021).toFixed(1)} kW</td>
                      <td className="py-2.5 text-[#35C99A] font-semibold">97.9%</td>
                      <td className="py-2.5 text-right font-mono text-[#F8FAFC]">0.98</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* Printable PDF Preview Modal */}
      <Modal
        isOpen={showPdfModal}
        onClose={() => setShowPdfModal(false)}
        title="GRIDMIND AI — Operational Report Document"
        subtitle={`Period: ${dateRange} • Category: ${reportType}`}
        maxWidth="2xl"
      >
        <div className="space-y-4 text-xs text-[#F8FAFC]">
          <div className="border border-[#34495E] p-4 rounded-xl bg-[#152538] space-y-3">
            <div className="flex justify-between items-start border-b border-[#34495E] pb-3">
              <div>
                <h3 className="text-base font-bold text-[#F8FAFC]">GRIDMIND AI OPERATIONS SUMMARY</h3>
                <p className="text-[10px] text-[#A9B8C8]">
                  Theme: AI-Driven Active Distribution Grid System
                </p>
              </div>
              <div className="text-right text-[10px] text-[#A9B8C8]">
                <span>Date: 2026-11-14</span>
                <span className="block">Status: Certified SCADA Archive</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center py-2">
              <div className="p-2 bg-[#1D3045] rounded-lg">
                <span className="text-[10px] text-[#A9B8C8] block">Total Ingested Load</span>
                <span className="font-bold text-[#20A99E]">4,820 kW</span>
              </div>
              <div className="p-2 bg-[#1D3045] rounded-lg">
                <span className="text-[10px] text-[#A9B8C8] block">30m AI Forecast</span>
                <span className="font-bold text-[#9585F5]">5,140 kW</span>
              </div>
              <div className="p-2 bg-[#1D3045] rounded-lg">
                <span className="text-[10px] text-[#A9B8C8] block">Model R² Accuracy</span>
                <span className="font-bold text-[#35C99A]">0.978</span>
              </div>
              <div className="p-2 bg-[#1D3045] rounded-lg">
                <span className="text-[10px] text-[#A9B8C8] block">Active Transformers</span>
                <span className="font-bold text-[#F8FAFC]">18 / 18</span>
              </div>
            </div>

            <p className="text-[11px] text-[#A9B8C8] leading-relaxed">
              This report certifies that the distribution grid operated within nominal frequency (50.02 Hz)
              and primary bus voltage (11.04 kV) boundaries. The Random Forest demand regression model
              accurately anticipated evening peak loads, maintaining zero feeder trips and avoiding manual
              load shedding.
            </p>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" size="sm" onClick={() => setShowPdfModal(false)}>
              Close
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={Printer}
              onClick={() => {
                window.print();
                setShowPdfModal(false);
              }}
            >
              Print Document
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
