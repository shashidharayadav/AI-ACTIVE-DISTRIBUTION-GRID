"""
GRIDMIND AI - Interactive What-If Simulator Calculation Engine
Strictly implements:
- Consumer demand category breakdown (Residential, Industrial, Commercial)
- Temperature cooling sensitivity & Industrial shift multipliers
- Rooftop Solar PV infeed deductions
- BESS dispatch power sign integration
- Accurate Net Grid Demand and Net Usable Balance calculations:
  Net Grid Demand = Consumer Demand - Solar PV
  Adjusted Grid Demand = Net Grid Demand + BESS Charging - BESS Discharging
  Net Usable Balance = Incoming Supply - Adjusted Grid Demand - Network Losses
- Grid Health Index calculation (GRIDMIND demo metric)
- 5 Dynamic Presets (Nominal, Solar Peak, Evening Surge, Heatwave, Industrial Shift)
"""
from typing import Dict, Any, List
from app.services.energy_calculations import calculate_energy_balance
from app.database.repositories.grid_repository import grid_repo
import logging

logger = logging.getLogger("gridmind.services.simulator")


class SimulatorService:
    def __init__(self):
        # Baseline category loads (summing to 4,820 kW nominal total)
        self.baseline_residential_kw: float = 1650.0
        self.baseline_industrial_kw: float = 1820.0
        self.baseline_commercial_kw: float = 1350.0
        self.baseline_total_demand_kw: float = 4820.0
        self.baseline_supply_kw: float = 5400.0

    def calculate_simulation(
        self,
        demand_change_pct: float = 0.0,
        solar_pv_generation_kw: float = 350.0,
        industrial_activity_pct: float = 100.0,
        ambient_temperature_c: float = 28.5,
        grid_supply_kw: float = 5400.0,
        bess_dispatch_kw: float = -420.0
    ) -> Dict[str, Any]:
        """
        Runs the full What-If simulation calculation.
        """
        demand_multiplier = 1.0 + (demand_change_pct / 100.0)

        # Temperature sensitivity: Residential cooling expands above 25°C (~2.2% per °C)
        temp_delta = max(0.0, ambient_temperature_c - 25.0)
        residential_temp_factor = 1.0 + (temp_delta * 0.022)
        commercial_temp_factor = 1.0 + (temp_delta * 0.015)

        # 1. Adjusted Category Demands
        adjusted_residential = round(self.baseline_residential_kw * demand_multiplier * residential_temp_factor, 1)
        adjusted_industrial = round(
            self.baseline_industrial_kw * (industrial_activity_pct / 100.0) * (1.0 + (demand_multiplier - 1.0) * 0.4),
            1
        )
        adjusted_commercial = round(self.baseline_commercial_kw * demand_multiplier * commercial_temp_factor, 1)

        total_consumer_demand = round(adjusted_residential + adjusted_industrial + adjusted_commercial, 1)

        # 2. Net Grid Demand
        net_grid_demand = round(max(0.0, total_consumer_demand - solar_pv_generation_kw), 1)

        # 3. BESS Power Sign Convention
        # Negative = Charging (increases grid demand), Positive = Discharging (reduces grid demand)
        bess_charging_kw = abs(bess_dispatch_kw) if bess_dispatch_kw < 0 else 0.0
        bess_discharging_kw = bess_dispatch_kw if bess_dispatch_kw > 0 else 0.0

        adjusted_grid_demand = round(net_grid_demand + bess_charging_kw - bess_discharging_kw, 1)

        # 4. Losses (~2.2% of active flow)
        network_losses = round(adjusted_grid_demand * 0.022, 1)

        # 5. Net Usable Balance
        net_usable_balance = round(grid_supply_kw - adjusted_grid_demand - network_losses, 1)

        if net_usable_balance > 50.0:
            balance_status = "SURPLUS"
            dispatch_rec = f"Usable surplus of +{net_usable_balance} kW available. Recommend routing to BESS or adjacent deficit feeders."
        elif net_usable_balance < -30.0:
            balance_status = "DEFICIT"
            dispatch_rec = f"Net deficit of {abs(net_usable_balance)} kW detected. Recommend BESS peak discharge or tie-feeder transfer."
        else:
            balance_status = "BALANCED"
            dispatch_rec = "Grid operating at near-perfect balance with optimal frequency & voltage regulation."

        # 6. Equipment Loading & Health Score
        feeder_loading_pct = round((adjusted_grid_demand / 6000.0) * 100.0, 1)
        transformer_loading_pct = round((adjusted_grid_demand / 5800.0) * 100.0, 1)

        # Grid Health Score (Demo metric 0 - 100%)
        health_penalties = 0.0
        if feeder_loading_pct > 80.0:
            health_penalties += (feeder_loading_pct - 80.0) * 1.5
        if transformer_loading_pct > 80.0:
            health_penalties += (transformer_loading_pct - 80.0) * 1.8
        if net_usable_balance < 0:
            health_penalties += min(25.0, abs(net_usable_balance) * 0.04)

        grid_health_score = round(max(45.0, min(100.0, 100.0 - health_penalties)), 1)

        # Active Warnings
        warnings = []
        if feeder_loading_pct >= 85.0:
            warnings.append(f"Feeder loading elevated at {feeder_loading_pct}%")
        if transformer_loading_pct >= 85.0:
            warnings.append(f"Transformer fleet loading elevated at {transformer_loading_pct}%")
        if net_usable_balance < 0:
            warnings.append(f"Active power deficit of {abs(net_usable_balance)} kW")
        if ambient_temperature_c >= 38.0:
            warnings.append(f"Severe ambient thermal stress ({ambient_temperature_c}°C)")

        return {
            "baseline_demand_kw": self.baseline_total_demand_kw,
            "adjusted_residential_kw": adjusted_residential,
            "adjusted_industrial_kw": adjusted_industrial,
            "adjusted_commercial_kw": adjusted_commercial,
            "total_consumer_demand_kw": total_consumer_demand,
            "solar_pv_generation_kw": solar_pv_generation_kw,
            "net_grid_demand_kw": net_grid_demand,
            "incoming_grid_supply_kw": grid_supply_kw,
            "network_losses_kw": network_losses,
            "bess_power_kw": bess_dispatch_kw,
            "net_usable_balance_kw": net_usable_balance,
            "grid_balance_status": balance_status,
            "feeder_loading_pct": feeder_loading_pct,
            "transformer_loading_pct": transformer_loading_pct,
            "grid_health_score": grid_health_score,
            "dispatch_recommendation": dispatch_rec,
            "active_warnings": warnings
        }

    def get_presets(self) -> List[Dict[str, Any]]:
        """
        Returns the 5 defined preset scenarios.
        """
        presets = [
            {
                "id": "PRESET-01",
                "name": "Nominal Operations",
                "description": "Standard baseline operation with nominal solar infeed and active BESS surplus charging.",
                "inputs": {
                    "demandChangePct": 0.0,
                    "solarPvGenerationKw": 350.0,
                    "industrialActivityPct": 100.0,
                    "ambientTemperatureC": 28.5,
                    "gridSupplyKw": 5400.0,
                    "bessDispatchKw": -420.0
                }
            },
            {
                "id": "PRESET-02",
                "name": "Midday Solar Peak Surplus",
                "description": "Maximum rooftop solar generation producing high usable surplus across distribution feeders.",
                "inputs": {
                    "demandChangePct": -5.0,
                    "solarPvGenerationKw": 1450.0,
                    "industrialActivityPct": 95.0,
                    "ambientTemperatureC": 32.0,
                    "gridSupplyKw": 5400.0,
                    "bessDispatchKw": -1200.0
                }
            },
            {
                "id": "PRESET-03",
                "name": "Evening Residential Peak Surge",
                "description": "Post-sunset peak residential load surge with zero solar infeed requiring BESS support.",
                "inputs": {
                    "demandChangePct": 18.0,
                    "solarPvGenerationKw": 0.0,
                    "industrialActivityPct": 85.0,
                    "ambientTemperatureC": 27.0,
                    "gridSupplyKw": 5400.0,
                    "bessDispatchKw": 850.0
                }
            },
            {
                "id": "PRESET-04",
                "name": "Heatwave Severe Grid Stress",
                "description": "Extremely high 41.5°C temperature driving peak air-conditioning loads and equipment thermal warnings.",
                "inputs": {
                    "demandChangePct": 26.0,
                    "solarPvGenerationKw": 600.0,
                    "industrialActivityPct": 110.0,
                    "ambientTemperatureC": 41.5,
                    "gridSupplyKw": 5400.0,
                    "bessDispatchKw": 1500.0
                }
            },
            {
                "id": "PRESET-05",
                "name": "Industrial Heavy Shift",
                "description": "Full industrial zone capacity shift with 140% manufacturing load index.",
                "inputs": {
                    "demandChangePct": 12.0,
                    "solarPvGenerationKw": 250.0,
                    "industrialActivityPct": 140.0,
                    "ambientTemperatureC": 29.0,
                    "gridSupplyKw": 5600.0,
                    "bessDispatchKw": 400.0
                }
            }
        ]
        # Calculate outputs for each preset dynamically
        for p in presets:
            inp = p["inputs"]
            p["results"] = self.calculate_simulation(
                demand_change_pct=inp["demandChangePct"],
                solar_pv_generation_kw=inp["solarPvGenerationKw"],
                industrial_activity_pct=inp["industrialActivityPct"],
                ambient_temperature_c=inp["ambientTemperatureC"],
                grid_supply_kw=inp["gridSupplyKw"],
                bess_dispatch_kw=inp["bessDispatchKw"]
            )
        return presets


# Singleton instance
simulator_service = SimulatorService()
