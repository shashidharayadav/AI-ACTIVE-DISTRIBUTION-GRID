import React, { useState } from 'react';
import {
  Sliders,
  Cpu,
  Sun,
  Factory,
  Thermometer,
  Zap,
  BatteryCharging,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Activity
} from 'lucide-react';
import { defaultWhatIfParams, mockWhatIfPresets } from '../data/mockData';
import type { WhatIfSimulationParams } from '../types';

export const WhatIfSimulator: React.FC = () => {
  const [params, setParams] = useState<WhatIfSimulationParams>(defaultWhatIfParams);
  const [activePresetName, setActivePresetName] = useState<string>('Nominal Operations');

  // =========================================================
  // CLEARLY DEFINED MATHEMATICAL CALCULATION MODEL
  // =========================================================

  // 1. Separate Baseline Allocations (Total baseline = 4,820 kW)
  const baselineConsumerDemand = 3600; // kW (Residential, Commercial, Municipal)
  const baselineIndustrialDemand = 1220; // kW (Heavy manufacturing / Industrial estate)

  // 2. Separate Demand Adjustments (No double counting)
  const adjustedConsumerDemand = Math.round(
    baselineConsumerDemand * (1 + params.demandChangePct / 100)
  );
  const adjustedIndustrialDemand = Math.round(
    baselineIndustrialDemand * (params.industrialActivityPct / 100)
  );
  const totalGrossDemand = adjustedConsumerDemand + adjustedIndustrialDemand;

  // 3. Solar PV Distributed Generation Offset
  const solarGenerationOffset = params.solarPvGenerationKw;

  // 4. Net Grid Demand (Actual load met by transmission and battery)
  const netGridDemand = Math.max(800, totalGrossDemand - solarGenerationOffset);

  // 5. Technical Network Losses (Simulated physical model: I²R ohmic heating + ambient thermal factor)
  const tempThermalFactor = 1 + (params.ambientTemperatureC - 28) * 0.015;
  const loadingRatio = netGridDemand / 4820;
  const calculatedLossesKw = Math.round(108 * Math.pow(loadingRatio, 2) * tempThermalFactor);

  // 6. Net Usable Balance Calculation
  // Sign convention: BESS > 0 (Discharging: supplies power to grid), BESS < 0 (Charging: absorbs grid surplus)
  const netGridBalanceKw = params.gridSupplyKw + params.bessDispatchKw - netGridDemand - calculatedLossesKw;

  // 7. Feeder Loading Percentage (Rated Feeder Capacity: 6,000 kW)
  const ratedFeederCapacityKw = 6000;
  const avgFeederLoadingPct = parseFloat(
    Math.min(120, (netGridDemand / ratedFeederCapacityKw) * 100).toFixed(1)
  );

  // 8. Transformer Hotspot Temperature (Simulated thermal rise model)
  const hotspotTempC = parseFloat(
    (params.ambientTemperatureC + 35 * Math.pow(loadingRatio, 1.6)).toFixed(1)
  );

  // 9. Defined Simulated Grid Health Score (Deduction-based index)
  let healthScore = 98.4;
  if (avgFeederLoadingPct > 80) healthScore -= (avgFeederLoadingPct - 80) * 1.5;
  if (hotspotTempC > 75) healthScore -= (hotspotTempC - 75) * 1.2;
  if (netGridBalanceKw < 0) healthScore -= Math.min(35, Math.abs(netGridBalanceKw) / 35);
  healthScore = Math.max(35, Math.min(99.5, parseFloat(healthScore.toFixed(1))));

  const isSurplus = netGridBalanceKw > 50;
  const isDeficit = netGridBalanceKw < -50;

  // Dispatch advisory logic
  let advisoryType: 'success' | 'warning' | 'critical' = 'success';
  let advisoryTitle = 'Grid Dispatched Nominally';
  let advisoryText = 'Distribution parameters are operating within statutory IEEE/BESCOM limits.';

  if (isDeficit) {
    const rawDeficit = Math.abs(netGridBalanceKw);
    advisoryType = 'critical';
    advisoryTitle = 'Distribution Deficit Detected';
    if (params.bessDispatchKw <= 0) {
      advisoryText = `Net deficit of -${rawDeficit.toLocaleString()} kW. Recommend BESS discharge (up to 2,000 kW) to shave peak and relieve transmission feed.`;
    } else {
      const remainingDeficit = rawDeficit;
      advisoryText = `Active BESS discharge of +${params.bessDispatchKw} kW is applied. Remaining grid deficit is -${remainingDeficit.toLocaleString()} kW. Consider load curtailment.`;
    }
  } else if (isSurplus) {
    advisoryType = 'success';
    advisoryTitle = 'Distribution Surplus Available';
    const maxChargeSurplus = Math.min(2500, netGridBalanceKw);
    if (params.bessDispatchKw === 0) {
      advisoryText = `Usable surplus of +${netGridBalanceKw.toLocaleString()} kW available. Recommend charging BESS unit up to ${maxChargeSurplus.toLocaleString()} kW to prevent curtailment.`;
    } else if (params.bessDispatchKw < 0) {
      advisoryText = `BESS is actively absorbing ${Math.abs(params.bessDispatchKw).toLocaleString()} kW. Remaining usable surplus is +${netGridBalanceKw.toLocaleString()} kW.`;
    } else {
      advisoryText = `Surplus of +${netGridBalanceKw.toLocaleString()} kW exists. BESS discharge (+${params.bessDispatchKw} kW) is active but may not be required during surplus.`;
    }
  }

  // Thermal & Loading Warnings
  const hasThermalWarning = hotspotTempC > 80;
  const hasOverloadWarning = avgFeederLoadingPct > 85;

  const handleApplyPreset = (preset: typeof mockWhatIfPresets[0]) => {
    setParams({ ...preset.params });
    setActivePresetName(preset.name);
  };

  const handleReset = () => {
    setParams({ ...defaultWhatIfParams });
    setActivePresetName('Nominal Operations');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/30 text-[#20A99E]">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-[#F8FAFC] tracking-tight">
                INTERACTIVE WHAT-IF SIMULATOR
              </h1>
              <p className="text-xs text-[#A9B8C8]">
                Multi-Variable Grid Sensitivity Modeling • Real-time Demand, Solar & Temperature Stress Testing
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls & Reset */}
        <div className="flex items-center gap-2.5">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30">
            SIMULATION ENGINE ACTIVE
          </span>
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1D3045] hover:bg-[#263B50] text-[#A9B8C8] hover:text-[#F8FAFC] text-xs border border-[#34495E] transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Baseline</span>
          </button>
        </div>
      </div>

      {/* Preset Scenarios Pill Bar */}
      <div className="bg-[#152538] border border-[#34495E] rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2 text-xs font-bold text-[#F8FAFC] uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-[#20A99E]" />
            Instant Grid Stress Scenarios (Click to Load)
          </div>
          <span className="text-[11px] font-mono text-[#20A99E]">Active: {activePresetName}</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {mockWhatIfPresets.map((preset) => {
            const isSelected = activePresetName === preset.name;
            return (
              <button
                key={preset.name}
                onClick={() => handleApplyPreset(preset)}
                className={`p-2.5 rounded-lg border text-left transition-all ${
                  isSelected
                    ? 'bg-[#20A99E]/15 border-[#20A99E] shadow-sm'
                    : 'bg-[#1D3045] border-[#34495E] hover:border-[#20A99E]/50'
                }`}
              >
                <div
                  className={`text-xs font-bold ${
                    isSelected ? 'text-[#20A99E]' : 'text-[#F8FAFC]'
                  }`}
                >
                  {preset.name}
                </div>
                <div className="text-[10px] text-[#A9B8C8] line-clamp-2 mt-1">
                  {preset.description}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary Layout: Controls (Left) vs Real-Time Dynamic Outputs (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Parameter Slider Controls */}
        <div className="lg:col-span-7 bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-[#34495E]">
            <h2 className="text-sm font-bold text-[#F8FAFC] flex items-center gap-2 uppercase tracking-wider">
              <Sliders className="w-4 h-4 text-[#20A99E]" />
              Distribution Input Variables
            </h2>
            <span className="text-[10px] text-[#A9B8C8]">Dynamic Sensitivity</span>
          </div>

          {/* Slider 1: Consumer Demand Variation */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-[#20A99E]" />
                Consumer Demand Variation (Baseline 3,600 kW)
              </span>
              <span className="font-mono font-bold text-[#20A99E]">
                {params.demandChangePct > 0 ? `+${params.demandChangePct}%` : `${params.demandChangePct}%`}
                <span className="text-[#A9B8C8] font-normal ml-1">({adjustedConsumerDemand.toLocaleString()} kW)</span>
              </span>
            </div>
            <input
              type="range"
              min="-30"
              max="50"
              step="5"
              value={params.demandChangePct}
              onChange={(e) => {
                setParams({ ...params, demandChangePct: Number(e.target.value) });
                setActivePresetName('Custom Setting');
              }}
              className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#20A99E]"
            />
            <div className="flex justify-between text-[10px] text-[#A9B8C8]">
              <span>Off-Peak (-30%)</span>
              <span>Nominal (0%)</span>
              <span>Extreme Surge (+50%)</span>
            </div>
          </div>

          {/* Slider 2: Rooftop Solar PV Generation */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                <Sun className="w-3.5 h-3.5 text-[#F5B942]" />
                Rooftop Solar PV Distributed Offset
              </span>
              <span className="font-mono font-bold text-[#F5B942]">
                {params.solarPvGenerationKw.toLocaleString()} kW
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="2500"
              step="50"
              value={params.solarPvGenerationKw}
              onChange={(e) => {
                setParams({ ...params, solarPvGenerationKw: Number(e.target.value) });
                setActivePresetName('Custom Setting');
              }}
              className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#F5B942]"
            />
            <div className="flex justify-between text-[10px] text-[#A9B8C8]">
              <span>0 kW (Night/Overcast)</span>
              <span>1,250 kW (Typical)</span>
              <span>2,500 kW (Clear Solar Noon)</span>
            </div>
          </div>

          {/* Slider 3: Industrial Activity Index */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                <Factory className="w-3.5 h-3.5 text-[#9585F5]" />
                Industrial Heavy Load Activity (Baseline 1,220 kW)
              </span>
              <span className="font-mono font-bold text-[#9585F5]">
                {params.industrialActivityPct}%
                <span className="text-[#A9B8C8] font-normal ml-1">({adjustedIndustrialDemand.toLocaleString()} kW)</span>
              </span>
            </div>
            <input
              type="range"
              min="50"
              max="150"
              step="5"
              value={params.industrialActivityPct}
              onChange={(e) => {
                setParams({ ...params, industrialActivityPct: Number(e.target.value) });
                setActivePresetName('Custom Setting');
              }}
              className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#9585F5]"
            />
            <div className="flex justify-between text-[10px] text-[#A9B8C8]">
              <span>50% (Weekend Low)</span>
              <span>100% (Normal Shift)</span>
              <span>150% (Peak Heavy Duty)</span>
            </div>
          </div>

          {/* Slider 4: Ambient Temperature */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-[#F16F75]" />
                Ambient Air Temperature (Thermal Impact)
              </span>
              <span className="font-mono font-bold text-[#F16F75]">
                {params.ambientTemperatureC}°C
              </span>
            </div>
            <input
              type="range"
              min="18"
              max="45"
              step="1"
              value={params.ambientTemperatureC}
              onChange={(e) => {
                setParams({ ...params, ambientTemperatureC: Number(e.target.value) });
                setActivePresetName('Custom Setting');
              }}
              className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#F16F75]"
            />
            <div className="flex justify-between text-[10px] text-[#A9B8C8]">
              <span>18°C (Cool Season)</span>
              <span>28°C (Nominal Baseline)</span>
              <span>45°C (Severe Heatwave)</span>
            </div>
          </div>

          {/* Slider 5: Incoming Grid Supply */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-[#35C99A]" />
                Incoming Substation Transmission Feed
              </span>
              <span className="font-mono font-bold text-[#35C99A]">
                {params.gridSupplyKw.toLocaleString()} kW
              </span>
            </div>
            <input
              type="range"
              min="3500"
              max="7500"
              step="100"
              value={params.gridSupplyKw}
              onChange={(e) => {
                setParams({ ...params, gridSupplyKw: Number(e.target.value) });
                setActivePresetName('Custom Setting');
              }}
              className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#35C99A]"
            />
            <div className="flex justify-between text-[10px] text-[#A9B8C8]">
              <span>3,500 kW (Restricted)</span>
              <span>5,400 kW (Standard)</span>
              <span>7,500 kW (High Capacity)</span>
            </div>
          </div>

          {/* Slider 6: BESS Dispatch Injection / Charge */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                <BatteryCharging className="w-3.5 h-3.5 text-[#20A99E]" />
                Battery Storage (BESS) Dispatch Setpoint
              </span>
              <span className="font-mono font-bold text-[#20A99E]">
                {params.bessDispatchKw > 0
                  ? `Discharge +${params.bessDispatchKw.toLocaleString()} kW (Inject)`
                  : params.bessDispatchKw < 0
                  ? `Charge ${params.bessDispatchKw.toLocaleString()} kW (Absorb)`
                  : '0 kW (Idle)'}
              </span>
            </div>
            <input
              type="range"
              min="-2000"
              max="2000"
              step="100"
              value={params.bessDispatchKw}
              onChange={(e) => {
                setParams({ ...params, bessDispatchKw: Number(e.target.value) });
                setActivePresetName('Custom Setting');
              }}
              className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#20A99E]"
            />
            <div className="flex justify-between text-[10px] text-[#A9B8C8]">
              <span>-2,000 kW (Absorb Surplus)</span>
              <span>0 kW (Idle)</span>
              <span>+2,000 kW (Discharge Peak)</span>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Real-Time Dynamic Outputs */}
        <div className="lg:col-span-5 space-y-4">
          {/* Card 1: NET GRID DEMAND (Correctly labelled!) */}
          <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#A9B8C8] uppercase tracking-wider">
                NET GRID DEMAND
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded border bg-[#20A99E]/15 text-[#20A99E] border-[#20A99E]/30">
                ACTIVE LOAD
              </span>
            </div>

            <div>
              <div className="flex items-baseline gap-2 font-mono">
                <span className="text-3xl font-extrabold text-[#F8FAFC]">
                  {netGridDemand.toLocaleString()}
                </span>
                <span className="text-xs text-[#A9B8C8] font-bold">kW</span>
              </div>
              <p className="text-[11px] text-[#A9B8C8] mt-1">
                Consumer ({adjustedConsumerDemand.toLocaleString()} kW) + Industrial ({adjustedIndustrialDemand.toLocaleString()} kW) − Solar Offset ({solarGenerationOffset.toLocaleString()} kW)
              </p>
            </div>
          </div>

          {/* Card 2: NET USABLE BALANCE (Correctly labelled as Surplus or Deficit!) */}
          <div className={`bg-[#152538] border rounded-xl p-5 shadow-md space-y-3 ${
            isSurplus
              ? 'border-[#35C99A]/50'
              : isDeficit
              ? 'border-[#F16F75]/50'
              : 'border-[#20A99E]/50'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#A9B8C8] uppercase tracking-wider">
                {isSurplus ? 'NET USABLE SURPLUS' : isDeficit ? 'NET GRID DEFICIT' : 'NET USABLE BALANCE'}
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                  isSurplus
                    ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30'
                    : isDeficit
                    ? 'bg-[#F16F75]/15 text-[#F16F75] border-[#F16F75]/30'
                    : 'bg-[#20A99E]/15 text-[#20A99E] border-[#20A99E]/30'
                }`}
              >
                {isSurplus ? 'NET SURPLUS' : isDeficit ? 'DEFICIT ALERT' : 'BALANCED'}
              </span>
            </div>

            <div>
              <div className="flex items-baseline gap-2 font-mono">
                <span className={`text-3xl font-extrabold ${
                  netGridBalanceKw > 0
                    ? 'text-[#35C99A]'
                    : netGridBalanceKw < 0
                    ? 'text-[#F16F75]'
                    : 'text-[#F8FAFC]'
                }`}>
                  {netGridBalanceKw > 0 ? `+${netGridBalanceKw.toLocaleString()}` : netGridBalanceKw.toLocaleString()}
                </span>
                <span className="text-xs text-[#A9B8C8] font-bold">kW</span>
              </div>
            </div>

            {/* Grid Balance Indicator Breakdown */}
            <div className="bg-[#101C2C] p-3 rounded-lg border border-[#34495E] space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">Incoming Substation Supply:</span>
                <span className="font-mono font-bold text-[#F8FAFC]">
                  {params.gridSupplyKw.toLocaleString()} kW
                </span>
              </div>
              {params.bessDispatchKw !== 0 && (
                <div className="flex items-center justify-between">
                  <span className="text-[#A9B8C8]">BESS Dispatch Injection:</span>
                  <span className={`font-mono font-bold ${params.bessDispatchKw > 0 ? 'text-[#35C99A]' : 'text-[#9585F5]'}`}>
                    {params.bessDispatchKw > 0 ? `+${params.bessDispatchKw.toLocaleString()}` : `${params.bessDispatchKw.toLocaleString()}`} kW
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">Net Grid Demand:</span>
                <span className="font-mono font-bold text-[#F8FAFC]">
                  -{netGridDemand.toLocaleString()} kW
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">Estimated $I^2R$ Network Losses:</span>
                <span className="font-mono font-bold text-[#F5B942]">
                  -{calculatedLossesKw.toLocaleString()} kW
                </span>
              </div>
              <div className="pt-2 border-t border-[#34495E] flex items-center justify-between">
                <span className="font-bold text-[#F8FAFC]">Net Result:</span>
                <span
                  className={`font-mono text-sm font-extrabold ${
                    netGridBalanceKw > 0
                      ? 'text-[#35C99A]'
                      : netGridBalanceKw < 0
                      ? 'text-[#F16F75]'
                      : 'text-[#A9B8C8]'
                  }`}
                >
                  {netGridBalanceKw > 0 ? `+${netGridBalanceKw.toLocaleString()}` : netGridBalanceKw.toLocaleString()} kW
                </span>
              </div>
            </div>
          </div>

          {/* Key Metric Gauges */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#152538] border border-[#34495E] rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#A9B8C8] uppercase">
                  Feeder Loading
                </span>
                {hasOverloadWarning && (
                  <span className="text-[10px] font-bold text-[#F16F75]">OVERLOAD</span>
                )}
              </div>
              <div className="mt-1 font-mono text-2xl font-bold text-[#F8FAFC]">
                {avgFeederLoadingPct}%
              </div>
              <div className="w-full bg-[#101C2C] rounded-full h-1.5 mt-2 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    avgFeederLoadingPct > 85
                      ? 'bg-[#F16F75]'
                      : avgFeederLoadingPct > 75
                      ? 'bg-[#F5B942]'
                      : 'bg-[#35C99A]'
                  }`}
                  style={{ width: `${Math.min(100, avgFeederLoadingPct)}%` }}
                />
              </div>
              <p className="text-[10px] text-[#A9B8C8] mt-1.5">Rated: {ratedFeederCapacityKw.toLocaleString()} kW capacity</p>
            </div>

            <div className="bg-[#152538] border border-[#34495E] rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#A9B8C8] uppercase">
                  Hotspot Estimate
                </span>
                {hasThermalWarning && (
                  <span className="text-[10px] font-bold text-[#F16F75]">HIGH TEMP</span>
                )}
              </div>
              <div className="mt-1 font-mono text-2xl font-bold text-[#F8FAFC]">
                {hotspotTempC}°C
              </div>
              <div className="w-full bg-[#101C2C] rounded-full h-1.5 mt-2 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    hotspotTempC > 80
                      ? 'bg-[#F16F75]'
                      : hotspotTempC > 70
                      ? 'bg-[#F5B942]'
                      : 'bg-[#35C99A]'
                  }`}
                  style={{ width: `${Math.min(100, (hotspotTempC / 105) * 100)}%` }}
                />
              </div>
              <p className="text-[10px] text-[#A9B8C8] mt-1.5">Simulated transformer rise</p>
            </div>
          </div>

          {/* Grid Health Score Card */}
          <div className="bg-[#152538] border border-[#34495E] rounded-xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-[#A9B8C8] uppercase">
                Simulated Grid Health Score
              </span>
              <div className="mt-1 flex items-baseline gap-2">
                <span
                  className={`text-2xl font-extrabold font-mono ${
                    healthScore > 90
                      ? 'text-[#35C99A]'
                      : healthScore > 75
                      ? 'text-[#F5B942]'
                      : 'text-[#F16F75]'
                  }`}
                >
                  {healthScore}
                </span>
                <span className="text-xs text-[#A9B8C8]">/ 100</span>
              </div>
              <p className="text-[10px] text-[#A9B8C8] mt-0.5">Calculated from feeder loading, thermal & reserve margins</p>
            </div>
            <div className="p-3 rounded-xl bg-[#101C2C] border border-[#34495E]">
              <ShieldCheck
                className={`w-6 h-6 ${
                  healthScore > 90
                    ? 'text-[#35C99A]'
                    : healthScore > 75
                    ? 'text-[#F5B942]'
                    : 'text-[#F16F75]'
                }`}
              />
            </div>
          </div>

          {/* Dispatch Advisory Notice */}
          <div className={`bg-[#152538] border rounded-xl p-4 text-xs ${
            advisoryType === 'critical'
              ? 'border-[#F16F75]/50'
              : hasOverloadWarning || hasThermalWarning
              ? 'border-[#F5B942]/50'
              : 'border-[#20A99E]/50'
          }`}>
            <div className="flex items-center gap-1.5 font-bold uppercase mb-1 text-[#F8FAFC]">
              {advisoryType === 'critical' ? (
                <AlertTriangle className="w-4 h-4 text-[#F16F75]" />
              ) : (
                <Activity className="w-4 h-4 text-[#20A99E]" />
              )}
              <span>{advisoryTitle}</span>
            </div>
            <p className="text-[#A9B8C8] leading-relaxed">
              {advisoryText}
            </p>
            {(hasOverloadWarning || hasThermalWarning) && (
              <div className="mt-2 pt-2 border-t border-[#34495E] text-[11px] text-[#F5B942] space-y-0.5">
                {hasOverloadWarning && <div>• Feeder loading ({avgFeederLoadingPct}%) exceeds 85% continuous threshold.</div>}
                {hasThermalWarning && <div>• Transformer hotspot ({hotspotTempC}°C) exceeds 80°C threshold.</div>}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
