import React from 'react';
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import type { LocalityConsumption } from '../../types';

interface LocalityPieChartProps {
  data: LocalityConsumption[];
  height?: number;
}

export const LocalityPieChart: React.FC<LocalityPieChartProps> = ({
  data,
  height = 240,
}) => {
  const COLORS = ['#20A99E', '#35C99A', '#9585F5', '#F5B942', '#38BDF8', '#F16F75'];

  return (
    <div style={{ width: '100%', height }} className="relative flex items-center justify-center">
      <ResponsiveContainer>
        <PieChart>
          <Tooltip
            contentStyle={{
              backgroundColor: '#1D3045',
              borderColor: '#34495E',
              borderRadius: '8px',
              color: '#F8FAFC',
              fontSize: '12px',
            }}
            formatter={(value: any, _: any, item: any) => [
              `${value} kW (${item.payload.percentage}%)`,
              item.payload.name,
            ]}
          />
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={65}
            outerRadius={90}
            paddingAngle={4}
            dataKey="currentKw"
          >
            {data.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="#1D3045" strokeWidth={2} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
        <span className="text-xs text-[#A9B8C8] uppercase font-medium">Total Load</span>
        <span className="text-lg font-bold text-[#F8FAFC]">
          {data.reduce((acc, curr) => acc + curr.currentKw, 0).toLocaleString()}
        </span>
        <span className="text-[10px] text-[#20A99E] font-medium">kW</span>
      </div>
    </div>
  );
};
