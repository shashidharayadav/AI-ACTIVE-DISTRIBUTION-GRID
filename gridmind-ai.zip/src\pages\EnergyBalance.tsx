import React, { useState } from 'react';
import {
  Scale,
  Zap,
  TrendingUp,
  AlertCircle,
  RefreshCw,
  Info,
  CheckCircle2,
  ArrowRight,
  Filter,
  BarChart3,
  Layers,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { mockEnergyBalance, mockLocalityBalances } from '../data/mockData';

// 1. Minute-level interval dataset (15-minute SCADA intervals)
const minuteSeriesData = [
  { time: '21:00', incoming: 5300, demand: 4890, losses: 106, surplus: 304 },
  { time: '21:15', incoming: 5250, demand: 4810, losses: 102, surplus: 338 },
  { time: '21:30', incoming: 5200, demand: 4740, losses: 99, surplus: 361 },
  { time: '21:45', incoming: 5150, demand: 4620, losses: 95, surplus: 435 },
  { time: '22:00', incoming: 4800, demand: 3950, losses: 86, surplus: 764 },
  { time: '22:15', incoming: 5100, demand: 4410, losses: 96, surplus: 594 },
  { time: '22:30 (Live)', incoming: 5400, demand: 4820, losses: 108, surplus: 472 },
  { time: '22:45 (Est)', incoming: 5450, demand: 4980, losses: 112, surplus: 358 },
  { time: '23:00 (Pred)', incoming: 5500, demand: 5140, losses: 116, surplus: 244 },
];

// 2. Hourly profile dataset (Full 24-hour distribution curve)
const hourlySeriesData = [
  { time: '00:00', incoming: 3200, demand: 2420, losses: 54, surplus: 726 },
  { time: '03:00', incoming: 2800, demand: 2050, losses: 42, surplus: 708 },
  { time: '06:00', incoming: 3500, demand: 2650, losses: 58, surplus: 792 },
  { time: '09:00', incoming: 4800, demand: 4100, losses: 88, surplus: 612 },
  { time: '12:00', incoming: 5300, demand: 4720, losses: 104, surplus: 476 },
  { time: '15:00', incoming: 5200, demand: 4680, losses: 98, surplus: 422 },
  { time: '18:00', incoming: 5650, demand: 5280, losses: 126, surplus: 244 },
  { time: '21:00', incoming: 5300, demand: 4890, losses: 106, surplus: 304 },
  { time: '23:00', incoming: 5400, demand: 4820, losses: 108, surplus: 472 },
];

// 3. Daily aggregate dataset (Past 7 days energy balance in MWh)
const dailySeriesData = [
  { time: 'Mon 10 Nov', incoming: 118.4, demand: 104.2, losses: 2.4, surplus: 11.8 },
  { time: 'Tue 11 Nov', incoming: 121.2, demand: 107.5, losses: 2.5, surplus: 11.2 },
  { time: 'Wed 12 Nov', incoming: 120.6, demand: 106.8, losses: 2.4, surplus: 11.4 },
  { time: 'Thu 13 Nov', incoming: 123.5, demand: 109.1, losses: 2.6, surplus: 11.8 },
  { time: 'Fri 14 Nov', incoming: 124.8, demand: 110.4, losses: 2.7, surplus: 11.7 },
  { time: 'Sat 15 Nov', incoming: 112.0, demand: 96.5, losses: 2.1, surplus: 13.4 },
  { time: 'Sun 16 Nov', incoming: 108.5, demand: 92.8, losses: 1.9, surplus: 13.8 },
];

// Locality datasets per interval
const hourlyLocalityBalances = [
  {
    localityId: 'LOC-01',
    localityName: 'Tech Park Cyber Corridor',
    feederName: 'FDR-01 (11kV Commercial)',
    supplyAllocatedKw: 1480,
    demandMeasuredKw: 1290,
    lossesKw: 26,
    balanceKw: 164,
    status: 'SURPLUS' as const,
  },
  {
    localityId: 'LOC-02',
    localityName: 'Heavy Industrial Estate',
    feederName: 'FDR-03 (11kV Industrial-A)',
    supplyAllocatedKw: 1180,
    demandMeasuredKw: 1210,
    lossesKw: 32,
    balanceKw: -62,
    status: 'SHORTAGE' as const,
  },
  {
    localityId: 'LOC-03',
    localityName: 'Downtown Commercial Center',
    feederName: 'FDR-02 (11kV Commercial/Retail)',
    supplyAllocatedKw: 850,
    demandMeasuredKw: 820,
    lossesKw: 17,
    balanceKw: 13,
    status: 'BALANCED' as const,
  },
  {
    localityId: 'LOC-04',
    localityName: 'North Residential Valley',
    feederName: 'FDR-04 (11kV Domestic Express)',
    supplyAllocatedKw: 820,
    demandMeasuredKw: 640,
    lossesKw: 13,
    balanceKw: 167,
    status: 'SURPLUS' as const,
  },
  {
    localityId: 'LOC-05',
    localityName: 'Metro Transit & Railway Depot',
    feederName: 'FDR-05 (11kV Traction Line)',
    supplyAllocatedKw: 540,
    demandMeasuredKw: 470,
    lossesKw: 8,
    balanceKw: 62,
    status: 'SURPLUS' as const,
  },
  {
    localityId: 'LOC-06',
    localityName: 'Greenfield Health Care City',
    feederName: 'FDR-06 (11kV Critical Healthcare)',
    supplyAllocatedKw: 350,
    demandMeasuredKw: 275,
    lossesKw: 6,
    balanceKw: 69,
    status: 'SURPLUS' as const,
  },
];

const dailyLocalityBalances = [
  {
    localityId: 'LOC-01',
    localityName: 'Tech Park Cyber Corridor',
    feederName: 'FDR-01 (11kV Commercial)',
    supplyAllocatedKw: 35.5, // MWh daily average
    demandMeasuredKw: 31.2,
    lossesKw: 0.65,
    balanceKw: 3.65,
    status: 'SURPLUS' as const,
  },
  {
    localityId: 'LOC-02',
    localityName: 'Heavy Industrial Estate',
    feederName: 'FDR-03 (11kV Industrial-A)',
    supplyAllocatedKw: 28.4,
    demandMeasuredKw: 29.1,
    lossesKw: 0.78,
    balanceKw: -1.48,
    status: 'SHORTAGE' as const,
  },
  {
    localityId: 'LOC-03',
    localityName: 'Downtown Commercial Center',
    feederName: 'FDR-02 (11kV Commercial/Retail)',
    supplyAllocatedKw: 20.4,
    demandMeasuredKw: 19.8,
    lossesKw: 0.42,
    balanceKw: 0.18,
    status: 'BALANCED' as const,
  },
  {
    localityId: 'LOC-04',
    localityName: 'North Residential Valley',
    feederName: 'FDR-04 (11kV Domestic Express)',
    supplyAllocatedKw: 19.8,
    demandMeasuredKw: 15.6,
    lossesKw: 0.33,
    balanceKw: 3.87,
    status: 'SURPLUS' as const,
  },
  {
    localityId: 'LOC-05',
    localityName: 'Metro Transit & Railway Depot',
    feederName: 'FDR-05 (11kV Traction Line)',
    supplyAllocatedKw: 13.0,
    demandMeasuredKw: 11.4,
    lossesKw: 0.20,
    balanceKw: 1.40,
    status: 'SURPLUS' as const,
  },
  {
    localityId: 'LOC-06',
    localityName: 'Greenfield Health Care City',
    feederName: 'FDR-06 (11kV Critical Healthcare)',
    supplyAllocatedKw: 8.4,
    demandMeasuredKw: 6.7,
    lossesKw: 0.14,
    balanceKw: 1.56,
    status: 'SURPLUS' as const,
  },
];

export const EnergyBalance: React.FC = () => {
  const [selectedInterval, setSelectedInterval] = useState<'15min' | 'hourly' | 'daily'>('15min');
  const [localityFilter, setLocalityFilter] = useState<'ALL' | 'SURPLUS' | 'SHORTAGE'>('ALL');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState('22:30:15');
  const [balanceData, setBalanceData] = useState(mockEnergyBalance);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      const now = new Date();
      setLastSyncTime(
        `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`
      );
      setBalanceData({
        ...mockEnergyBalance,
        incomingPowerKw: 5400 + Math.floor(Math.random() * 40 - 20),
        consumerDemandKw: 4820 + Math.floor(Math.random() * 30 - 15),
      });
      setIsRefreshing(false);
    }, 600);
  };

  // Select chart series and locality balances based on active interval
  const currentChartData =
    selectedInterval === '15min'
      ? minuteSeriesData
      : selectedInterval === 'hourly'
      ? hourlySeriesData
      : dailySeriesData;

  const activeLocalityDataset =
    selectedInterval === '15min'
      ? mockLocalityBalances
      : selectedInterval === 'hourly'
      ? hourlyLocalityBalances
      : dailyLocalityBalances;

  const filteredLocalities = activeLocalityDataset.filter((loc) => {
    if (localityFilter === 'ALL') return true;
    return loc.status === localityFilter;
  });

  // Dynamic KPI and unit formatting based on selected interval
  const isDaily = selectedInterval === 'daily';
  const unit = isDaily ? 'MWh' : 'kW';

  const displayIncoming = isDaily ? 124.8 : selectedInterval === 'hourly' ? 4572 : balanceData.incomingPowerKw;
  const displayDemand = isDaily ? 110.4 : selectedInterval === 'hourly' ? 3968 : balanceData.consumerDemandKw;
  const displayLosses = isDaily ? 2.7 : selectedInterval === 'hourly' ? 87.1 : balanceData.technicalLossesKw;
  const displaySurplus = isDaily ? 11.7 : selectedInterval === 'hourly' ? 516.9 : balanceData.netAvailableSurplusKw;

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/30 text-[#20A99E]">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-[#F8FAFC] tracking-tight">
                ENERGY BALANCE INTERFACE
              </h1>
              <p className="text-xs text-[#A9B8C8]">
                Real-time Active Substation Power Audit, Technical Loss Decomposition & Usable Surplus
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls & System Status */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#101C2C] border border-[#34495E] text-xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#35C99A] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#35C99A]" />
            </span>
            <span className="text-[#A9B8C8]">SCADA Synced:</span>
            <span className="font-mono font-medium text-[#F8FAFC]">{lastSyncTime}</span>
          </div>

          <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30">
            DEMO MODE
          </span>

          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-[#20A99E] hover:bg-[#1b8e85] text-[#101C2C] font-semibold text-xs transition-colors disabled:opacity-50 shadow-md"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{isRefreshing ? 'Recalculating...' : 'Re-calculate SCADA'}</span>
          </button>
        </div>
      </div>

      {/* Conceptual Energy Balance Formula Display Card */}
      <div className="bg-gradient-to-r from-[#152538] via-[#1D3045] to-[#152538] border border-[#20A99E]/40 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#20A99E]/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#20A99E]">
              <Layers className="w-4 h-4" />
              <span>Fundamental Grid Conservation Law</span>
            </div>
            <div className="font-mono text-sm md:text-base font-bold text-[#F8FAFC]">
              Net Available Power = Incoming Power − Consumer Demand − Technical Losses
            </div>
            <p className="text-xs text-[#A9B8C8] max-w-2xl">
              Continuously balances active distribution feeder supply against metered end-user consumption and mathematical $I^2R$ network dissipation.
            </p>
          </div>

          {/* Real Equation Values Pill based on selected interval */}
          <div className="bg-[#101C2C]/90 border border-[#34495E] rounded-lg p-3 font-mono text-xs text-center lg:text-right shrink-0">
            <div className="text-[#A9B8C8] text-[10px] uppercase font-bold tracking-wider mb-1">
              Active Resolution: {selectedInterval === '15min' ? '15-Minute SCADA' : selectedInterval === 'hourly' ? 'Hourly Integrated' : 'Daily Aggregate'}
            </div>
            <div className="text-sm font-bold text-[#35C99A]">
              {displayIncoming.toLocaleString()} {unit} − {displayDemand.toLocaleString()} {unit} − {displayLosses.toLocaleString()} {unit} ={' '}
              <span className="text-[#20A99E] text-base underline decoration-2">
                +{displaySurplus.toLocaleString()} {unit}
              </span>
            </div>
            <div className="text-[10px] text-[#A9B8C8]/80 mt-1">
              {isDaily ? 'Daily Net Surplus Energy' : 'Residual Metering Discrepancy: ±12 kW (0.22% tolerance)'}
            </div>
          </div>
        </div>
      </div>

      {/* Primary Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Incoming Power */}
        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">
              {isDaily ? 'Daily Energy Supply' : 'Incoming Supply'}
            </span>
            <div className="p-1.5 rounded-lg bg-[#20A99E]/10 text-[#20A99E]">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-[#F8FAFC]">
                {displayIncoming.toLocaleString()}
              </span>
              <span className="text-xs font-semibold text-[#A9B8C8]">{unit}</span>
            </div>
            <div className="flex items-center gap-1.5 mt-1.5 text-xs text-[#35C99A]">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>110kV / 11kV Substation Feed</span>
            </div>
          </div>
        </div>

        {/* Consumer Demand */}
        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">
              {isDaily ? 'Daily Total Demand' : 'Consumer Demand'}
            </span>
            <div className="p-1.5 rounded-lg bg-[#9585F5]/10 text-[#9585F5]">
              <Cpu className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-[#F8FAFC]">
                {displayDemand.toLocaleString()}
              </span>
              <span className="text-xs font-semibold text-[#A9B8C8]">{unit}</span>
            </div>
            <div className="flex items-center gap-1.5 mt-1.5 text-xs text-[#A9B8C8]">
              <span>88.5% Load Factor</span>
            </div>
          </div>
        </div>

        {/* Technical Losses */}
        <div className="bg-[#1D3045] border border-[#34495E] rounded-xl p-4.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider">Technical Losses</span>
            <div className="p-1.5 rounded-lg bg-[#F5B942]/10 text-[#F5B942]">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-[#F5B942]">
                {typeof displayLosses === 'number' ? displayLosses.toFixed(1) : displayLosses}
              </span>
              <span className="text-xs font-semibold text-[#A9B8C8]">{unit}</span>
            </div>
            <div className="flex items-center gap-1.5 mt-1.5 text-xs text-[#A9B8C8]">
              <span>2.1% Overall Distribution Loss</span>
            </div>
          </div>
        </div>

        {/* Usable Surplus */}
        <div className="bg-[#1D3045] border border-[#35C99A]/40 rounded-xl p-4.5 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#35C99A]/10 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#35C99A] uppercase tracking-wider">
              {isDaily ? 'Net Daily Surplus' : 'Net Usable Surplus'}
            </span>
            <div className="p-1.5 rounded-lg bg-[#35C99A]/15 text-[#35C99A]">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-[#35C99A]">
                +{typeof displaySurplus === 'number' ? displaySurplus.toLocaleString() : displaySurplus}
              </span>
              <span className="text-xs font-semibold text-[#A9B8C8]">{unit}</span>
            </div>
            <div className="flex items-center gap-1.5 mt-1.5 text-xs text-[#35C99A]">
              <span>Available for BESS / Tie-Transfer</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Charts & Decomposition Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Energy Balance Timeline Chart */}
        <div className="lg:col-span-2 bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div>
              <h2 className="text-base font-bold text-[#F8FAFC] flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-[#20A99E]" />
                Supply, Demand & Loss Profile ({unit})
              </h2>
              <p className="text-xs text-[#A9B8C8]">
                {selectedInterval === '15min'
                  ? 'Real-time 15-minute SCADA intervals comparing supply, demand, and surplus'
                  : selectedInterval === 'hourly'
                  ? '24-hour diurnal profile showing hourly aggregated power flows'
                  : '7-day daily cumulative energy balance (MWh per day)'}
              </p>
            </div>

            {/* Time Interval Selector (Clickable & Fully Functional!) */}
            <div className="flex items-center bg-[#101C2C] border border-[#34495E] rounded-lg p-1 self-start">
              <button
                type="button"
                onClick={() => setSelectedInterval('15min')}
                className={`px-3 py-1.5 text-xs rounded-md font-semibold transition-all cursor-pointer ${
                  selectedInterval === '15min'
                    ? 'bg-[#20A99E] text-[#101C2C] shadow-sm'
                    : 'text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]/60'
                }`}
              >
                Minutes
              </button>
              <button
                type="button"
                onClick={() => setSelectedInterval('hourly')}
                className={`px-3 py-1.5 text-xs rounded-md font-semibold transition-all cursor-pointer ${
                  selectedInterval === 'hourly'
                    ? 'bg-[#20A99E] text-[#101C2C] shadow-sm'
                    : 'text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]/60'
                }`}
              >
                Hours
              </button>
              <button
                type="button"
                onClick={() => setSelectedInterval('daily')}
                className={`px-3 py-1.5 text-xs rounded-md font-semibold transition-all cursor-pointer ${
                  selectedInterval === 'daily'
                    ? 'bg-[#20A99E] text-[#101C2C] shadow-sm'
                    : 'text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]/60'
                }`}
              >
                Days
              </button>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={currentChartData}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#263B50" vertical={false} />
                <XAxis
                  dataKey="time"
                  stroke="#A9B8C8"
                  fontSize={11}
                  tickLine={false}
                  minTickGap={15}
                />
                <YAxis
                  stroke="#A9B8C8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  width={50}
                  tickFormatter={(val) => `${val}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#101C2C',
                    borderColor: '#34495E',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                  formatter={(value: any, name: any) => [`${value} ${unit}`, name]}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                />
                <Bar
                  dataKey="demand"
                  name={isDaily ? 'Daily Demand (MWh)' : 'Consumer Demand (kW)'}
                  fill="#9585F5"
                  radius={[4, 4, 0, 0]}
                  barSize={18}
                />
                <Bar
                  dataKey="surplus"
                  name={isDaily ? 'Daily Surplus (MWh)' : 'Available Surplus (kW)'}
                  fill="#35C99A"
                  radius={[4, 4, 0, 0]}
                  barSize={18}
                />
                <Line
                  type="monotone"
                  dataKey="incoming"
                  name={isDaily ? 'Total Incoming Supply (MWh)' : 'Incoming Supply (kW)'}
                  stroke="#20A99E"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#20A99E' }}
                />
                <Line
                  type="monotone"
                  dataKey="losses"
                  name={isDaily ? 'Technical Losses (MWh)' : 'Technical Losses (kW)'}
                  stroke="#F5B942"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right 1 Col: Technical Losses Decomposition */}
        <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-[#F8FAFC] flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#F5B942]" />
                Loss Decomposition
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#F5B942]/15 text-[#F5B942] border border-[#F5B942]/30 font-mono">
                {isDaily ? '2.7 MWh / DAY' : `${balanceData.technicalLossesKw.toFixed(1)} kW TOTAL`}
              </span>
            </div>

            <p className="text-xs text-[#A9B8C8] mb-4 leading-relaxed">
              Distribution physics loss segregation based on real-time conductor impedance and magnetic core modeling.
            </p>

            <div className="space-y-4">
              {/* Feeder Conductor Line Losses */}
              <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E]">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-[#F8FAFC]">Conductor $I^2R$ Line Loss</span>
                  <span className="font-mono font-bold text-[#F5B942]">
                    {isDaily ? '1.37 MWh (50.7%)' : `${balanceData.technicalLossBreakdown.feederLineLossesKw} kW (50.7%)`}
                  </span>
                </div>
                <div className="w-full bg-[#101C2C] rounded-full h-2 overflow-hidden">
                  <div className="bg-[#F5B942] h-full rounded-full" style={{ width: '50.7%' }} />
                </div>
                <p className="text-[10px] text-[#A9B8C8] mt-1.5">
                  Ohmic resistance heating along 24 feeder cable runs.
                </p>
              </div>

              {/* Transformer Copper & Core Losses */}
              <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E]">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-[#F8FAFC]">Transformer Hysteresis & Copper</span>
                  <span className="font-mono font-bold text-[#20A99E]">
                    {isDaily ? '1.16 MWh (42.8%)' : `${balanceData.technicalLossBreakdown.transformerLossesKw} kW (42.8%)`}
                  </span>
                </div>
                <div className="w-full bg-[#101C2C] rounded-full h-2 overflow-hidden">
                  <div className="bg-[#20A99E] h-full rounded-full" style={{ width: '42.8%' }} />
                </div>
                <p className="text-[10px] text-[#A9B8C8] mt-1.5">
                  Magnetic eddy current core losses + coil resistance across 18 units.
                </p>
              </div>

              {/* Dielectric Leakage */}
              <div className="bg-[#1D3045] p-3 rounded-lg border border-[#34495E]">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-[#F8FAFC]">Dielectric & Reactive Leakage</span>
                  <span className="font-mono font-bold text-[#9585F5]">
                    {isDaily ? '0.17 MWh (6.5%)' : `${balanceData.technicalLossBreakdown.dielectricLossesKw} kW (6.5%)`}
                  </span>
                </div>
                <div className="w-full bg-[#101C2C] rounded-full h-2 overflow-hidden">
                  <div className="bg-[#9585F5] h-full rounded-full" style={{ width: '6.5%' }} />
                </div>
                <p className="text-[10px] text-[#A9B8C8] mt-1.5">
                  Insulation displacement currents in underground medium voltage lines.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#34495E] flex items-center justify-between text-xs text-[#A9B8C8]">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#35C99A]" />
              SCADA Error Bound: ±0.22%
            </span>
            <span className="font-mono text-[#F8FAFC]">Unexplained: {isDaily ? '0.08 MWh' : '12 kW'}</span>
          </div>
        </div>
      </div>

      {/* Locality-Level Energy Balance Roster */}
      <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-base font-bold text-[#F8FAFC] flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#20A99E]" />
              Locality Distribution Balances ({unit})
            </h2>
            <p className="text-xs text-[#A9B8C8]">
              Granular supply allocation vs measured consumer demand per distribution zone ({selectedInterval === '15min' ? '15-min live' : selectedInterval === 'hourly' ? 'hourly average' : 'daily cumulative'})
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 self-start">
            <span className="text-xs text-[#A9B8C8] flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              Filter:
            </span>
            <button
              onClick={() => setLocalityFilter('ALL')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                localityFilter === 'ALL'
                  ? 'bg-[#20A99E] text-[#101C2C] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              All ({activeLocalityDataset.length})
            </button>
            <button
              onClick={() => setLocalityFilter('SURPLUS')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                localityFilter === 'SURPLUS'
                  ? 'bg-[#35C99A] text-[#101C2C] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              Surplus
            </button>
            <button
              onClick={() => setLocalityFilter('SHORTAGE')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                localityFilter === 'SHORTAGE'
                  ? 'bg-[#F16F75] text-[#F8FAFC] font-semibold'
                  : 'bg-[#1D3045] text-[#A9B8C8] hover:text-[#F8FAFC] border border-[#34495E]'
              }`}
            >
              Shortage
            </button>
          </div>
        </div>

        {/* Table Container */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#A9B8C8]">
            <thead className="bg-[#101C2C] text-[#F8FAFC] uppercase text-[10px] tracking-wider border-y border-[#34495E]">
              <tr>
                <th className="py-3 px-3">Locality / Zone</th>
                <th className="py-3 px-3">Feeder Route</th>
                <th className="py-3 px-3">Supply Allocated ({unit})</th>
                <th className="py-3 px-3">Demand Measured ({unit})</th>
                <th className="py-3 px-3">Est. Losses ({unit})</th>
                <th className="py-3 px-3">Net Balance ({unit})</th>
                <th className="py-3 px-3 text-right">Operational Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#34495E]/50">
              {filteredLocalities.map((loc) => (
                <tr key={loc.localityId} className="hover:bg-[#1D3045]/60 transition-colors">
                  <td className="py-3 px-3 font-semibold text-[#F8FAFC]">
                    {loc.localityName}
                    <div className="text-[10px] text-[#A9B8C8] font-mono">{loc.localityId}</div>
                  </td>
                  <td className="py-3 px-3 font-mono text-[#A9B8C8]">{loc.feederName}</td>
                  <td className="py-3 px-3 font-mono text-[#F8FAFC] font-medium">
                    {loc.supplyAllocatedKw.toLocaleString()} {unit}
                  </td>
                  <td className="py-3 px-3 font-mono text-[#F8FAFC]">
                    {loc.demandMeasuredKw.toLocaleString()} {unit}
                  </td>
                  <td className="py-3 px-3 font-mono text-[#F5B942]">
                    {loc.lossesKw} {unit}
                  </td>
                  <td className="py-3 px-3 font-mono font-bold">
                    <span
                      className={
                        loc.balanceKw > 0
                          ? 'text-[#35C99A]'
                          : loc.balanceKw < 0
                          ? 'text-[#F16F75]'
                          : 'text-[#A9B8C8]'
                      }
                    >
                      {loc.balanceKw > 0 ? `+${loc.balanceKw}` : loc.balanceKw} {unit}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${
                        loc.status === 'SURPLUS'
                          ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30'
                          : loc.status === 'SHORTAGE'
                          ? 'bg-[#F16F75]/15 text-[#F16F75] border-[#F16F75]/30'
                          : 'bg-[#20A99E]/15 text-[#20A99E] border-[#20A99E]/30'
                      }`}
                    >
                      {loc.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer info box */}
        <div className="mt-4 p-3 bg-[#101C2C] border border-[#34495E] rounded-lg flex flex-col sm:flex-row items-center justify-between text-xs text-[#A9B8C8] gap-2">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-[#20A99E] shrink-0" />
            <span>
              Transfer recommendations can be reviewed and executed in the <strong>Surplus Electricity Management</strong> module.
            </span>
          </div>
          <a
            href="/surplus-management"
            className="flex items-center gap-1.5 text-[#20A99E] hover:underline font-semibold shrink-0"
          >
            Open Surplus Routing
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
