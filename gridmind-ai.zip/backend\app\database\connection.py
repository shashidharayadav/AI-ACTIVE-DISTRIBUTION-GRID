"""
GRIDMIND AI - Supabase & Data Store Connection Manager
"""
import logging
from typing import Optional, Any, Tuple
from app.core.config import settings

logger = logging.getLogger("gridmind.database")

# Global Supabase client instance
_supabase_client: Optional[Any] = None


def get_supabase_key() -> str:
    """Safely retrieves the configured Supabase key without exposing it."""
    return (
        settings.SUPABASE_SECRET_KEY
        or settings.SUPABASE_SERVICE_ROLE_KEY
        or settings.SUPABASE_ANON_KEY
    )


def get_supabase_client() -> Optional[Any]:
    """
    Returns an initialized Supabase client if valid credentials are provided in .env,
    or None if running in local simulation/repository mode.
    Never logs or exposes the secret key.
    """
    global _supabase_client
    if _supabase_client is not None:
        return _supabase_client

    key = get_supabase_key()
    if settings.SUPABASE_URL and key:
        try:
            from supabase import create_client
            # Strip trailing slash from URL for clean connection
            url = settings.SUPABASE_URL.strip().rstrip("/")
            _supabase_client = create_client(url, key.strip())
            # Safely mask the URL domain in logs without exposing tokens
            domain = url.split("//")[-1]
            logger.info("Supabase client initialized for host: %s", domain)
            return _supabase_client
        except Exception as e:
            logger.warning("Failed to initialize Supabase client (%s). Using local repository store.", str(e))
            return None
    else:
        logger.info("Supabase credentials not configured in .env. Running with local simulated repository store.")
        return None


def test_supabase_connection() -> Tuple[bool, str]:
    """
    Performs an actual connection verification test against the Supabase database.
    Does not print, expose, or log any secret key.
    Returns (success: bool, message: str).
    """
    client = get_supabase_client()
    if client is None:
        return False, "Supabase client not initialized: SUPABASE_URL or SUPABASE_SECRET_KEY is missing or empty in .env"

    try:
        # Test query to check if database is reachable and schema exists
        response = client.table("substations").select("count", count="exact").limit(1).execute()
        return True, "Successfully connected to Supabase PostgreSQL database."
    except Exception as e:
        err_msg = str(e)
        if "relation \"public.substations\" does not exist" in err_msg or "PGRST205" in err_msg or "relation" in err_msg:
            return True, "Connected to Supabase PostgreSQL, but tables not yet created. Execute create_schema.sql in Supabase SQL Editor."
        return False, f"Supabase connection test failed: {err_msg}"

