"""
GRIDMIND AI - Transformers Fleet Monitoring API Routes
"""
from fastapi import APIRouter, HTTPException
from typing import List
from app.database.repositories.grid_repository import grid_repo
from app.schemas.grid_schemas import TransformerItemSchema

router = APIRouter(prefix="/transformers", tags=["Transformers"])


@router.get("", response_model=List[TransformerItemSchema])
def list_transformers():
    return [TransformerItemSchema(**t) for t in grid_repo.get_transformers()]


@router.get("/{transformer_id}", response_model=TransformerItemSchema)
def get_transformer(transformer_id: str):
    t = grid_repo.get_transformer_by_id(transformer_id)
    if not t:
        raise HTTPException(status_code=404, detail=f"Transformer '{transformer_id}' not found")
    return TransformerItemSchema(**t)
