"""
GRIDMIND AI - Isolation Forest Telemetry Anomaly Detection Engine
Identifies unusual multidimensional grid observations across:
- Feeder demand variations
- Transformer thermal and apparent load surges
- Bus voltage and frequency sags/swells
- High harmonic distortion (THD%)
- Phase unbalance deviations
"""
import os
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional
from sklearn.ensemble import IsolationForest
import logging

logger = logging.getLogger("gridmind.ml.anomaly")


class IsolationForestAnomalyDetector:
    def __init__(self, model_dir: Optional[str] = None):
        if model_dir is None:
            model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "saved_models")
        self.model_dir = model_dir
        os.makedirs(self.model_dir, exist_ok=True)
        self.model_path = os.path.join(self.model_dir, "isolation_forest_anomaly.joblib")
        self.model: Optional[IsolationForest] = None
        self.features: List[str] = [
            "active_power_kw",
            "voltage_kv",
            "current_a",
            "frequency_hz",
            "thd_percent",
            "power_factor"
        ]
        self._load_or_initialize()

    def _load_or_initialize(self):
        if os.path.exists(self.model_path):
            try:
                self.model = joblib.load(self.model_path)
                logger.info("Loaded persisted Isolation Forest model from %s", self.model_path)
            except Exception as e:
                logger.warning("Could not load Isolation Forest (%s). Training new model.", e)
                self.train_and_save()
        else:
            logger.info("No persisted Isolation Forest found. Initializing training.")
            self.train_and_save()

    def train_and_save(self) -> Dict[str, Any]:
        """
        Trains IsolationForest on nominal electrical operating telemetry.
        """
        np.random.seed(42)
        n_samples = 3000

        # Nominal distribution conditions
        power = np.random.normal(1000.0, 250.0, n_samples).clip(200.0, 1800.0)
        voltage = np.random.normal(11.02, 0.08, n_samples).clip(10.5, 11.5)
        current = (power * 1000.0) / (np.sqrt(3) * (voltage * 1000.0) * 0.98)
        freq = np.random.normal(50.01, 0.03, n_samples).clip(49.8, 50.2)
        thd = np.random.exponential(1.5, n_samples).clip(0.5, 3.8)
        pf = np.random.normal(0.98, 0.01, n_samples).clip(0.92, 0.99)

        X_nominal = pd.DataFrame({
            "active_power_kw": power,
            "voltage_kv": voltage,
            "current_a": current,
            "frequency_hz": freq,
            "thd_percent": thd,
            "power_factor": pf
        })

        # Inject minor historical anomalies (~3% contamination)
        n_anom = int(n_samples * 0.03)
        anom_power = np.random.uniform(1850.0, 2400.0, n_anom)
        anom_voltage = np.random.choice([np.random.uniform(9.8, 10.2), np.random.uniform(11.75, 12.2)], n_anom)
        anom_current = (anom_power * 1000.0) / (np.sqrt(3) * (anom_voltage * 1000.0) * 0.90)
        anom_freq = np.random.choice([np.random.uniform(49.1, 49.4), np.random.uniform(50.6, 50.9)], n_anom)
        anom_thd = np.random.uniform(5.5, 9.8, n_anom)
        anom_pf = np.random.uniform(0.72, 0.85, n_anom)

        X_anom = pd.DataFrame({
            "active_power_kw": anom_power,
            "voltage_kv": anom_voltage,
            "current_a": anom_current,
            "frequency_hz": anom_freq,
            "thd_percent": anom_thd,
            "power_factor": anom_pf
        })

        X_train = pd.concat([X_nominal, X_anom]).sample(frac=1.0, random_state=42).reset_index(drop=True)

        iso = IsolationForest(
            n_estimators=100,
            contamination=0.03,
            random_state=42,
            n_jobs=-1
        )
        iso.fit(X_train)

        self.model = iso
        joblib.dump(self.model, self.model_path)
        logger.info("Isolation Forest trained & persisted to %s", self.model_path)
        return {"status": "SUCCESS", "n_samples": len(X_train)}

    def detect(
        self,
        active_power_kw: float,
        voltage_kv: float,
        current_a: float,
        frequency_hz: float,
        thd_percent: float,
        power_factor: float = 0.98,
        equipment_code: str = "FEEDER-FDR-01"
    ) -> Dict[str, Any]:
        """
        Evaluates a single telemetry sample for anomalies.
        Returns: is_anomaly, anomaly_score, severity, contributing factors.
        """
        sample = pd.DataFrame([{
            "active_power_kw": active_power_kw,
            "voltage_kv": voltage_kv,
            "current_a": current_a,
            "frequency_hz": frequency_hz,
            "thd_percent": thd_percent,
            "power_factor": power_factor
        }])

        if self.model is None:
            self._load_or_initialize()

        raw_pred = self.model.predict(sample)[0]  # -1 for anomaly, 1 for normal
        decision_score = float(self.model.decision_function(sample)[0])  # Negative = more anomalous

        is_anomaly = bool(raw_pred == -1)
        normalized_score = round(float(np.clip((0.5 - decision_score) * 100.0, 0.0, 100.0)), 1)

        contributing_factors = []
        if active_power_kw > 1800.0:
            contributing_factors.append(f"High Active Power ({active_power_kw} kW > 1,800 kW)")
        if voltage_kv < 10.34 or voltage_kv > 11.66:
            contributing_factors.append(f"Voltage Deviation ({voltage_kv} kV outside +/-6% 11kV band)")
        if frequency_hz < 49.5 or frequency_hz > 50.5:
            contributing_factors.append(f"Frequency Instability ({frequency_hz} Hz outside 50.0 +/-0.5 Hz)")
        if thd_percent > 5.0:
            contributing_factors.append(f"Excessive Harmonics (THD {thd_percent}% > 5.0% IEEE 519 limit)")
        if power_factor < 0.90:
            contributing_factors.append(f"Low Power Factor ({power_factor} < 0.90 lag)")

        if is_anomaly:
            severity = "CRITICAL" if normalized_score > 75.0 or len(contributing_factors) >= 2 else "WARNING"
        else:
            severity = "NORMAL"

        return {
            "is_anomaly": is_anomaly,
            "anomaly_score": normalized_score,
            "severity": severity,
            "contributing_factors": contributing_factors if contributing_factors else ["Nominal Operations"],
            "equipment_code": equipment_code,
            "timestamp": pd.Timestamp.now(tz="UTC").isoformat()
        }


# Singleton instance
anomaly_detector = IsolationForestAnomalyDetector()
