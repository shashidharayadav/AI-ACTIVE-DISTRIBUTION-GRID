import React, { useState } from 'react';
import {
  Bell,
  AlertTriangle,
  CheckCircle2,
  Search,
  CheckCheck,
  Eye,
  RotateCcw,
  ShieldAlert
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { Button } from '../components/common/Button';
import { useAlerts } from '../context/AlertsContext';

export const Alerts: React.FC = () => {
  const {
    alerts,
    resolvedAlerts,
    unreadCount,
    activeAlertsCount,
    criticalCount,
    warningCount,
    unackCount,
    acknowledgeAlert,
    resolveAlert,
    markAsRead,
    markAllAsRead,
    acknowledgeAll,
    reactivateAlert,
  } = useAlerts();

  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'ACKED' | 'RESOLVED' | 'UNREAD'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Filtering
  const filteredAlerts = alerts.filter((a) => {
    const matchesSeverity = severityFilter === 'ALL' || a.severity === severityFilter;
    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'ACTIVE' && !a.isResolved) ||
      (statusFilter === 'ACKED' && a.isAcknowledged && !a.isResolved) ||
      (statusFilter === 'RESOLVED' && a.isResolved) ||
      (statusFilter === 'UNREAD' && !a.isRead);
    const matchesSearch =
      a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.sourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSeverity && matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            Active Alerts & Incident Dispatch Queue
          </h2>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Real-time alarm telemetry from transformers, feeders, and Random Forest prediction thresholds
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {unackCount > 0 && (
            <Button
              variant="secondary"
              size="sm"
              icon={CheckCheck}
              onClick={acknowledgeAll}
            >
              Acknowledge All ({unackCount})
            </Button>
          )}

          {unreadCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              icon={Eye}
              onClick={markAllAsRead}
            >
              Mark All as Read ({unreadCount})
            </Button>
          )}
        </div>
      </div>

      {/* KPI Counters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Critical Alarms"
          value={criticalCount}
          unit="Active"
          icon={ShieldAlert}
          subtitle="Immediate response required"
          accent="red"
        />
        <MetricCard
          title="Warning Alerts"
          value={warningCount}
          unit="Active"
          icon={AlertTriangle}
          subtitle="Thermal & Load Thresholds"
          accent="amber"
        />
        <MetricCard
          title="Unread Notifications"
          value={unreadCount}
          unit="Queue"
          icon={Bell}
          subtitle="Awaiting operator review"
          accent="teal"
        />
        <MetricCard
          title="Resolved Incidents"
          value={resolvedAlerts.length}
          unit="Total"
          icon={CheckCircle2}
          subtitle="Archived in history"
          accent="emerald"
        />
      </div>

      {/* Filter Tabs & Search Bar */}
      <Card noPadding={true}>
        <div className="p-4 border-b border-[#34495E] flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Status Tabs */}
          <div className="flex flex-wrap items-center gap-1">
            {[
              { id: 'ALL', label: `All (${alerts.length})` },
              { id: 'ACTIVE', label: `Active Problems (${activeAlertsCount})` },
              { id: 'RESOLVED', label: `Resolved History (${resolvedAlerts.length})` },
              { id: 'UNREAD', label: `Unread (${unreadCount})` },
              { id: 'ACKED', label: 'Acknowledged' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  statusFilter === tab.id
                    ? 'bg-[#20A99E] text-[#101C2C]'
                    : 'text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Severity & Search */}
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg bg-[#152538] border border-[#34495E] text-xs text-[#F8FAFC] focus:outline-none"
            >
              <option value="ALL">All Severities</option>
              <option value="critical">Critical Only</option>
              <option value="warning">Warning Only</option>
              <option value="info">Info Only</option>
            </select>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#A9B8C8]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search alerts..."
                className="pl-8 pr-3 py-1.5 rounded-lg bg-[#152538] border border-[#34495E] text-xs text-[#F8FAFC] placeholder-[#A9B8C8]/50 focus:outline-none focus:border-[#20A99E]"
              />
            </div>
          </div>
        </div>

        {/* Alerts List */}
        <div className="divide-y divide-[#34495E]/60 p-2">
          {filteredAlerts.length === 0 ? (
            <div className="py-12 text-center text-xs text-[#A9B8C8]">
              No alerts matching the selected filter criteria.
            </div>
          ) : (
            filteredAlerts.map((alt) => (
              <div
                key={alt.id}
                className={`p-4 rounded-xl transition-all m-2 flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  !alt.isResolved && alt.severity === 'critical'
                    ? 'bg-[#F16F75]/10 border border-[#F16F75]/30'
                    : !alt.isResolved && alt.severity === 'warning'
                    ? 'bg-[#F5B942]/10 border border-[#F5B942]/30'
                    : alt.isResolved
                    ? 'bg-[#152538]/70 border border-[#34495E]/60'
                    : 'bg-[#152538] border border-[#34495E]'
                }`}
              >
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <StatusBadge status={alt.severity} size="sm" />
                    <span className="font-mono text-xs text-[#A9B8C8]">{alt.id}</span>
                    <h4 className="text-sm font-bold text-[#F8FAFC]">{alt.title}</h4>

                    {/* Operational Status (Active vs Resolved) */}
                    {alt.isResolved ? (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#35C99A]/20 text-[#35C99A] border border-[#35C99A]/30">
                        RESOLVED
                      </span>
                    ) : alt.isAcknowledged ? (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#20A99E]/20 text-[#20A99E] border border-[#20A99E]/30">
                        ACKNOWLEDGED
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#F16F75]/20 text-[#F16F75] border border-[#F16F75]/30 animate-pulse">
                        ACTIVE PROBLEM
                      </span>
                    )}

                    {/* Notification State: Unread vs Read */}
                    {!alt.isRead ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#20A99E] animate-ping" />
                        UNREAD
                      </span>
                    ) : (
                      <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-[#101C2C] text-[#A9B8C8] border border-[#34495E]">
                        READ
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-[#A9B8C8] leading-relaxed">{alt.description}</p>

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-[#A9B8C8]/80 pt-1">
                    <span>
                      Asset: <strong className="text-[#F8FAFC]">{alt.sourceName}</strong>
                    </span>
                    <span>•</span>
                    <span>Reported: {alt.timestamp}</span>
                    {alt.acknowledgedBy && (
                      <>
                        <span>•</span>
                        <span className="text-[#20A99E]">Acked by: {alt.acknowledgedBy}</span>
                      </>
                    )}
                    {alt.resolvedAt && (
                      <>
                        <span>•</span>
                        <span className="text-[#35C99A]">Resolved at: {alt.resolvedAt}</span>
                      </>
                    )}
                    {alt.readAt && (
                      <>
                        <span>•</span>
                        <span className="text-[#A9B8C8]">Read at: {alt.readAt}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Actions: Distinct for Active vs Resolved */}
                <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
                  {/* If ACTIVE problem: Acknowledge & Resolve actions */}
                  {!alt.isResolved && (
                    <>
                      {!alt.isAcknowledged && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => acknowledgeAlert(alt.id)}
                        >
                          Acknowledge
                        </Button>
                      )}
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => resolveAlert(alt.id)}
                      >
                        Resolve Problem
                      </Button>
                    </>
                  )}

                  {/* If RESOLVED: Display clearly visible Mark as Read action if unread, or Closed status */}
                  {alt.isResolved && (
                    <>
                      {!alt.isRead ? (
                        <Button
                          variant="outline"
                          size="sm"
                          icon={CheckCheck}
                          onClick={() => markAsRead(alt.id)}
                        >
                          Mark as Read
                        </Button>
                      ) : (
                        <span className="text-xs text-[#35C99A] font-semibold flex items-center gap-1.5 px-2 py-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Read & Preserved</span>
                        </span>
                      )}

                      {/* Option to re-test / reactivate for simulation */}
                      <button
                        onClick={() => reactivateAlert(alt.id)}
                        title="Simulate Recurring Problem"
                        className="p-1.5 rounded-lg text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50] transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};
