import React, { createContext, useContext, useState, useEffect } from 'react';
import type { AlertItem } from '../types';
import { mockAlerts } from '../data/mockData';
import { gridmindApi } from '../services/api';

interface AlertsContextType {
  alerts: AlertItem[];
  activeAlerts: AlertItem[];
  resolvedAlerts: AlertItem[];
  unreadAlerts: AlertItem[];
  unreadCount: number;
  activeAlertsCount: number;
  criticalCount: number;
  warningCount: number;
  infoCount: number;
  unackCount: number;
  acknowledgeAlert: (id: string, operatorName?: string) => void;
  resolveAlert: (id: string, operatorName?: string) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  acknowledgeAll: () => void;
  reactivateAlert: (id: string) => void;
  resetAlertsToDefault: () => void;
}

const AlertsContext = createContext<AlertsContextType | undefined>(undefined);

const STORAGE_KEY = 'gridmind_alerts_v2';

export const AlertsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [alerts, setAlerts] = useState<AlertItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed: AlertItem[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse saved alerts from localStorage', e);
      }
    }
    // Initial dataset with explicit isRead and isResolved values
    return mockAlerts.map((alt) => ({
      ...alt,
      // Default: If already resolved in mock data, ALT-3072 starts UNREAD to demonstrate Mark as Read, others read
      isRead: alt.id === 'ALT-3072' ? false : alt.isResolved ? true : false,
    }));
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(alerts));
    } catch (e) {
      console.error('Failed to persist alerts to localStorage', e);
    }
  }, [alerts]);

  // Sync from FastAPI / Supabase backend on mount
  useEffect(() => {
    let isMounted = true;
    gridmindApi
      .getAlerts()
      .then((serverAlerts) => {
        if (isMounted && serverAlerts && serverAlerts.length > 0) {
          setAlerts((prev) => {
            const localMap = new Map(
              prev.map((a) => [a.id, { isRead: a.isRead, isAcknowledged: a.isAcknowledged, isResolved: a.isResolved }])
            );
            return serverAlerts.map((sa) => {
              const local = localMap.get(sa.id);
              return {
                ...sa,
                isRead: local ? local.isRead : sa.isRead ?? false,
                isAcknowledged: local ? local.isAcknowledged : sa.isAcknowledged ?? false,
                isResolved: local ? local.isResolved : sa.isResolved ?? false,
              };
            });
          });
        }
      })
      .catch((err) => {
        console.warn('[AlertsContext] Could not load alerts from backend:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // Derived state subsets
  const activeAlerts = alerts.filter((a) => !a.isResolved);
  const resolvedAlerts = alerts.filter((a) => a.isResolved);
  const unreadAlerts = alerts.filter((a) => !a.isRead);

  // Unread notification count (decreases when any notification is marked as read)
  const unreadCount = alerts.filter((a) => !a.isRead).length;

  // Active problem count (only unresolved incidents)
  const activeAlertsCount = activeAlerts.length;

  // Severity metrics for active problems
  const criticalCount = activeAlerts.filter((a) => a.severity === 'critical').length;
  const warningCount = activeAlerts.filter((a) => a.severity === 'warning').length;
  const infoCount = activeAlerts.filter((a) => a.severity === 'info').length;

  // Unacknowledged active alarms
  const unackCount = activeAlerts.filter((a) => !a.isAcknowledged).length;

  // 1. Acknowledge Action
  const acknowledgeAlert = (id: string, operatorName = 'Current Dispatcher') => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isAcknowledged: true, acknowledgedBy: operatorName } : a))
    );
  };

  // 2. Resolve Action: Sets isResolved to true. Remains unread (isRead: false) until marked as read.
  const resolveAlert = (id: string, operatorName = 'Current Dispatcher') => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          return {
            ...a,
            isAcknowledged: true,
            isResolved: true,
            isRead: false, // Resolved notifications remain UNREAD until user clicks Mark as Read
            resolvedAt: timeStr,
            acknowledgedBy: a.acknowledgedBy || operatorName,
          };
        }
        return a;
      })
    );

    gridmindApi.resolveAlert(id).catch((e) => console.warn('[AlertsContext] Resolve sync warning:', e));
  };

  // 3. Mark as Read Action: Marks specific notification as read, decrements unreadCount, preserves alert
  const markAsRead = (id: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isRead: true, readAt: timeStr } : a))
    );

    gridmindApi.markAlertAsRead(id).catch((e) => console.warn('[AlertsContext] Mark read sync warning:', e));
  };

  // 4. Mark All as Read Action
  const markAllAsRead = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => (!a.isRead ? { ...a, isRead: true, readAt: timeStr } : a))
    );
  };

  // 5. Acknowledge All Active Action
  const acknowledgeAll = () => {
    setAlerts((prev) =>
      prev.map((a) => (!a.isResolved ? { ...a, isAcknowledged: true, acknowledgedBy: 'Lead Dispatcher' } : a))
    );
  };

  // 6. Reactivate Alert (if a problem recurs, handle cleanly)
  const reactivateAlert = (id: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          return {
            ...a,
            isResolved: false,
            isAcknowledged: false,
            isRead: false,
            timestamp: `Re-triggered at ${timeStr}`,
          };
        }
        return a;
      })
    );
  };

  // 7. Reset to Default mock alerts
  const resetAlertsToDefault = () => {
    const fresh = mockAlerts.map((alt) => ({
      ...alt,
      isRead: alt.id === 'ALT-3072' ? false : alt.isResolved ? true : false,
    }));
    setAlerts(fresh);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
  };

  return (
    <AlertsContext.Provider
      value={{
        alerts,
        activeAlerts,
        resolvedAlerts,
        unreadAlerts,
        unreadCount,
        activeAlertsCount,
        criticalCount,
        warningCount,
        infoCount,
        unackCount,
        acknowledgeAlert,
        resolveAlert,
        markAsRead,
        markAllAsRead,
        acknowledgeAll,
        reactivateAlert,
        resetAlertsToDefault,
      }}
    >
      {children}
    </AlertsContext.Provider>
  );
};

export const useAlerts = (): AlertsContextType => {
  const context = useContext(AlertsContext);
  if (!context) {
    throw new Error('useAlerts must be used within an AlertsProvider');
  }
  return context;
};
